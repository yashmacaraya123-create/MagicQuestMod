export default function App() {
  return (
    <main className="flex min-h-screen items-center justify-center bg-[#0d0820] p-6 text-violet-100">
      <div className="w-full max-w-md space-y-4 rounded-2xl border border-violet-500/30 bg-[#150d2e] p-6">
        <h1 className="text-xl font-semibold text-white">Magical Quest v0.1.0</h1>
        <p className="text-sm text-violet-300">Forge 1.20.1 mod by Yash. Downloads:</p>
        <a
          href="./magicalquest-source.zip"
          download
          className="block rounded-lg bg-violet-600 px-4 py-3 text-center font-medium text-white hover:bg-violet-500"
        >
          magicalquest-source.zip (upload to GitHub)
        </a>
        <a
          href="./magicalquest-0.1.0.jar"
          download
          className="block rounded-lg border border-violet-500/40 px-4 py-3 text-center font-medium text-violet-100 hover:bg-violet-500/10"
        >
          magicalquest-0.1.0.jar (prebuilt, untested in-game)
        </a>
      </div>
    </main>
  );
}
