package com.yash.magicalquest.client;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.network.chat.Style;

import java.util.List;

/** Small text helpers for the custom screens. */
public final class ClientText {
    private ClientText() {
    }

    public static List<String> wrap(Font font, String text, int width) {
        return font.getSplitter().splitLines(text, Math.max(20, width), Style.EMPTY)
                .stream().map(FormattedText::getString).toList();
    }

    /** Draws wrapped lines with a typewriter effect (chars = number of visible characters). */
    public static void drawTyped(GuiGraphics g, Font font, List<String> lines, int x, int y, int lineHeight,
                                 int color, int chars, boolean centered, int centerX) {
        int remaining = chars;
        for (String line : lines) {
            if (remaining <= 0) {
                break;
            }
            String shown = line.substring(0, Math.min(line.length(), remaining));
            remaining -= line.length();
            int dx = centered ? centerX - font.width(line) / 2 : x;
            g.drawString(font, shown, dx, y, color, true);
            y += lineHeight;
        }
    }
}
