package com.yash.magicalquest.network;

import com.yash.magicalquest.magic.SkillManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: pick the active skill from the skill wheel. */
public record SelectSkillPacket(String skillId) {
    public static void encode(SelectSkillPacket msg, FriendlyByteBuf buf) {
        buf.writeUtf(msg.skillId);
    }

    public static SelectSkillPacket decode(FriendlyByteBuf buf) {
        return new SelectSkillPacket(buf.readUtf());
    }

    public static void handle(SelectSkillPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player != null) {
                SkillManager.select(player, msg.skillId);
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
