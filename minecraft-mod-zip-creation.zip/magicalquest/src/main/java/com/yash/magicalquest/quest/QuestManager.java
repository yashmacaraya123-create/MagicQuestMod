package com.yash.magicalquest.quest;

import com.yash.magicalquest.entity.MageEntity;
import com.yash.magicalquest.magic.MagicCaps;
import com.yash.magicalquest.magic.PlayerMagic;
import com.yash.magicalquest.magic.SkillManager;
import com.yash.magicalquest.network.Net;
import com.yash.magicalquest.network.OpenDialogPacket;
import com.yash.magicalquest.skill.Skill;
import com.yash.magicalquest.skill.Skills;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;

/** Server-side quest flow: offering, tracking, completing and rewarding. */
public final class QuestManager {
    private QuestManager() {
    }

    // ----------------------------------------------------------------- lookup

    /** The next quest the Mage would offer to this player, or null. */
    public static Quest next(PlayerMagic m) {
        for (Quest q : Quests.all()) {
            if (m.completedQuests.contains(q.id)) {
                continue;
            }
            if (q.element != null && q.element != m.element) {
                continue;
            }
            if (m.completedQuests.size() < q.minCompleted) {
                continue;
            }
            return q;
        }
        return null;
    }

    public static Quest active(PlayerMagic m) {
        return Quests.get(m.activeQuest);
    }

    /** Works on both sides (COLLECT quests count the inventory live). */
    public static int progress(Player player, PlayerMagic m, Quest q) {
        if (q.type == QuestType.COLLECT) {
            return Math.min(q.count, countItems(player, q));
        }
        return Math.min(q.count, m.progress);
    }

    public static boolean isComplete(Player player, PlayerMagic m, Quest q) {
        return progress(player, m, q) >= q.count;
    }

    private static int countItems(Player player, Quest q) {
        int total = 0;
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            ItemStack st = player.getInventory().getItem(i);
            if (q.matchesItem(st)) {
                total += st.getCount();
            }
        }
        return total;
    }

    private static void removeItems(Player player, Quest q) {
        int left = q.count;
        for (int i = 0; i < player.getInventory().getContainerSize() && left > 0; i++) {
            ItemStack st = player.getInventory().getItem(i);
            if (q.matchesItem(st)) {
                int take = Math.min(left, st.getCount());
                st.shrink(take);
                left -= take;
            }
        }
    }

    // ----------------------------------------------------------------- dialogue

    public static void talk(ServerPlayer sp, MageEntity mage) {
        PlayerMagic m = PlayerMagic.get(sp);
        String name = mage.getName().getString();
        mage.getNavigation().stop();

        if (!m.chosen) {
            send(sp, mage, name, List.of("You have not awakened yet, traveller. Look inward and choose your element first."), 0, "");
            return;
        }

        Quest act = active(m);
        if (act != null) {
            if (isComplete(sp, m, act)) {
                send(sp, mage, name, claim(sp, m, act), 0, "");
            } else {
                int prog = progress(sp, m, act);
                send(sp, mage, name, List.of(
                        "You are still working on \"" + act.title + "\".",
                        act.objective(prog),
                        "Come back when it is done. The Goddess watches over you."), 0, "");
            }
            return;
        }

        Quest nx = next(m);
        if (nx == null) {
            send(sp, mage, name, List.of(
                    "You have finished every task I know of, reborn one. I have taught you all I can.",
                    "But the world is wide and the darkness is far from gone. Ruins, beasts and great evils still wait beyond the horizon.",
                    "Come back when new tales begin."), 0, "");
            return;
        }
        List<String> pages = new ArrayList<>(nx.story);
        String reward = rewardText(nx, m);
        pages.add("Quest: " + nx.title + "\n" + nx.objective(0).replaceAll(": 0/\\d+$", "") + "\nReward: " + reward
                + "\n\nWill you accept?");
        send(sp, mage, name, pages, 1, nx.id);
    }

    private static String rewardText(Quest q, PlayerMagic m) {
        List<String> parts = new ArrayList<>();
        if (q.rewardSkillIndex > 0 && q.element != null) {
            List<Skill> list = Skills.of(q.element);
            if (q.rewardSkillIndex < list.size()) {
                parts.add("Skill: " + list.get(q.rewardSkillIndex).name);
            }
        }
        for (Quest.Reward r : q.rewards) {
            parts.add(r.label());
        }
        parts.add(q.rewardXp + " XP");
        return String.join(", ", parts);
    }

    private static void send(ServerPlayer sp, MageEntity mage, String name, List<String> pages, int mode, String questId) {
        Net.toPlayer(sp, new OpenDialogPacket(mage.getId(), name, pages, mode, questId));
    }

    // ------------------------------------------------------------- accept / abandon

    public static void accept(ServerPlayer sp, String questId) {
        PlayerMagic m = PlayerMagic.get(sp);
        Quest q = Quests.get(questId);
        if (q == null || !m.chosen || !m.activeQuest.isEmpty() || next(m) != q) {
            return;
        }
        m.activeQuest = q.id;
        m.progress = 0;
        MagicCaps.sync(sp);
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.6f, 1.5f);
        SkillManager.title(sp, Component.literal("Quest Accepted").withStyle(ChatFormatting.GOLD),
                Component.literal(q.title).withStyle(ChatFormatting.YELLOW));
    }

    public static void abandon(ServerPlayer sp) {
        PlayerMagic m = PlayerMagic.get(sp);
        if (m.activeQuest.isEmpty()) {
            return;
        }
        m.activeQuest = "";
        m.progress = 0;
        MagicCaps.sync(sp);
        SkillManager.bar(sp, "Quest abandoned.", ChatFormatting.GRAY);
    }

    // ------------------------------------------------------------------ rewards

    private static List<String> claim(ServerPlayer sp, PlayerMagic m, Quest q) {
        if (q.type == QuestType.COLLECT) {
            removeItems(sp, q);
        }
        m.completedQuests.add(q.id);
        m.activeQuest = "";
        m.progress = 0;

        List<String> pages = new ArrayList<>();
        pages.add(q.done);
        List<String> got = new ArrayList<>();

        if (q.rewardSkillIndex > 0 && q.element != null) {
            List<Skill> list = Skills.of(q.element);
            if (q.rewardSkillIndex < list.size()) {
                Skill s = list.get(q.rewardSkillIndex);
                m.unlocked.add(s.id);
                got.add("New skill unlocked: " + s.name);
                SkillManager.title(sp, Component.literal("New Skill").withStyle(ChatFormatting.GOLD),
                        Component.literal(s.name).withStyle(Style.EMPTY.withColor(s.element.color)));
            }
        }
        for (Quest.Reward r : q.rewards) {
            ItemStack st = r.make().apply(m.element);
            if (!sp.getInventory().add(st)) {
                sp.drop(st, false);
            }
            got.add("Received: " + r.label());
        }
        sp.giveExperiencePoints(q.rewardXp);
        got.add("+" + q.rewardXp + " XP");
        m.mana = m.maxMana();
        pages.add("Quest complete: " + q.title + "\n\n" + String.join("\n", got));
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundSource.PLAYERS, 1f, 1f);
        MagicCaps.sync(sp);
        return pages;
    }

    // ------------------------------------------------------------ progress hooks

    private static void add(ServerPlayer sp, PlayerMagic m, Quest q, int amount) {
        int before = m.progress;
        m.progress = Math.min(q.count, m.progress + amount);
        if (m.progress != before) {
            MagicCaps.sync(sp);
            if (m.progress >= q.count) {
                SkillManager.title(sp, Component.literal("Objective Complete").withStyle(ChatFormatting.GREEN),
                        Component.literal("Return to a Village Mage").withStyle(ChatFormatting.GRAY));
                sp.level().playSound(null, sp.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 1f, 1f);
            } else {
                SkillManager.bar(sp, q.title + ": " + m.progress + "/" + q.count, ChatFormatting.YELLOW);
            }
        }
    }

    private static Quest activeOfType(PlayerMagic m, QuestType type) {
        Quest q = active(m);
        return q != null && q.type == type && m.progress < q.count ? q : null;
    }

    public static void onKill(ServerPlayer sp, EntityType<?> type) {
        PlayerMagic m = PlayerMagic.get(sp);
        Quest q = activeOfType(m, QuestType.KILL);
        if (q != null && q.matchesEntity(type)) {
            add(sp, m, q, 1);
        }
    }

    public static void onMine(ServerPlayer sp, BlockState state) {
        PlayerMagic m = PlayerMagic.get(sp);
        Quest q = activeOfType(m, QuestType.MINE);
        if (q != null && q.matchesBlock(state)) {
            add(sp, m, q, 1);
        }
    }

    public static void onPlace(ServerPlayer sp, BlockState state) {
        PlayerMagic m = PlayerMagic.get(sp);
        Quest q = activeOfType(m, QuestType.BUILD);
        if (q != null && q.matchesBlock(state)) {
            add(sp, m, q, 1);
        }
    }

    public static void onCraft(ServerPlayer sp, ItemStack crafted) {
        PlayerMagic m = PlayerMagic.get(sp);
        Quest q = activeOfType(m, QuestType.CRAFT);
        if (q != null && q.matchesItem(crafted)) {
            add(sp, m, q, Math.max(1, crafted.getCount()));
        }
    }

    public static void tickExplore(ServerPlayer sp) {
        PlayerMagic m = PlayerMagic.get(sp);
        Quest q = activeOfType(m, QuestType.EXPLORE);
        if (q != null && q.matchesBiome(sp.level().getBiome(sp.blockPosition()))) {
            add(sp, m, q, q.count);
        }
    }

    /** COLLECT quests: tell the player when they have gathered enough. */
    public static void tickCollect(ServerPlayer sp) {
        PlayerMagic m = PlayerMagic.get(sp);
        Quest q = active(m);
        if (q == null || q.type != QuestType.COLLECT) {
            return;
        }
        boolean complete = isComplete(sp, m, q);
        // progress field doubles as "already notified" flag for collect quests
        if (complete && m.progress < q.count) {
            m.progress = q.count;
            MagicCaps.sync(sp);
            SkillManager.title(sp, Component.literal("Objective Complete").withStyle(ChatFormatting.GREEN),
                    Component.literal("Return to a Village Mage").withStyle(ChatFormatting.GRAY));
        } else if (!complete && m.progress >= q.count) {
            m.progress = 0;
            MagicCaps.sync(sp);
        }
    }
}
