package com.yash.magicalquest.magic;

import com.yash.magicalquest.element.Element;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.entity.player.Player;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

/** All magical data attached to a player (saved with the player, synced to the client). */
public class PlayerMagic {
    private static final PlayerMagic FALLBACK = new PlayerMagic();

    public boolean chosen;
    public boolean rebirthPending;
    public Element element = Element.FIRE;
    public float mana = 100f;
    public final Set<String> unlocked = new LinkedHashSet<>();
    public final Set<String> completedQuests = new LinkedHashSet<>();
    public String activeQuest = "";
    public int progress;
    public String selected = "";
    public final Map<String, Integer> cooldowns = new HashMap<>();

    /** Runtime only (not saved). */
    public boolean manaDirty;
    public boolean hasCharm;

    public static PlayerMagic get(Player player) {
        return player.getCapability(MagicCaps.MAGIC).orElse(FALLBACK);
    }

    public float maxMana() {
        return 100f + unlocked.size() * 3f + completedQuests.size() * 3f;
    }

    public int cooldown(String skillId) {
        return cooldowns.getOrDefault(skillId, 0);
    }

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        tag.putBoolean("chosen", chosen);
        tag.putBoolean("rebirth", rebirthPending);
        tag.putInt("element", element.ordinal());
        tag.putFloat("mana", mana);
        tag.putString("active", activeQuest);
        tag.putInt("progress", progress);
        tag.putString("selected", selected);
        tag.put("unlocked", toList(unlocked));
        tag.put("completed", toList(completedQuests));
        CompoundTag cds = new CompoundTag();
        cooldowns.forEach(cds::putInt);
        tag.put("cooldowns", cds);
        return tag;
    }

    public void load(CompoundTag tag) {
        chosen = tag.getBoolean("chosen");
        rebirthPending = tag.getBoolean("rebirth");
        element = Element.byOrdinal(tag.getInt("element"));
        mana = tag.contains("mana") ? tag.getFloat("mana") : 100f;
        activeQuest = tag.getString("active");
        progress = tag.getInt("progress");
        selected = tag.getString("selected");
        fromList(tag.getList("unlocked", Tag.TAG_STRING), unlocked);
        fromList(tag.getList("completed", Tag.TAG_STRING), completedQuests);
        cooldowns.clear();
        CompoundTag cds = tag.getCompound("cooldowns");
        for (String key : cds.getAllKeys()) {
            cooldowns.put(key, cds.getInt(key));
        }
    }

    public void copyFrom(PlayerMagic other) {
        load(other.save());
    }

    private static ListTag toList(Set<String> set) {
        ListTag list = new ListTag();
        for (String s : set) {
            list.add(StringTag.valueOf(s));
        }
        return list;
    }

    private static void fromList(ListTag list, Set<String> out) {
        out.clear();
        for (int i = 0; i < list.size(); i++) {
            out.add(list.getString(i));
        }
    }
}
