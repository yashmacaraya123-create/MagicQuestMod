package com.yash.magicalquest.element;

import org.joml.Vector3f;

import java.util.Locale;

/** The seven elements a reborn soul can be bound to. */
public enum Element {
    FIRE("Fire", 0xFF5A1F,
            "Burning offense. Explosive damage and raw power.",
            "Passive: immune to fire and lava."),
    WATER("Water", 0x2F8CFF,
            "Fluid and resilient. Healing, control and freezing tides.",
            "Passive: breathe and swim freely in water."),
    EARTH("Earth", 0xB08A4E,
            "Unbreakable defense. Heavy hits and mountain-like health.",
            "Passive: +2 bonus hearts."),
    WIND("Wind", 0x7FE3C4,
            "Swift and free. Mobility, gusts and razor air.",
            "Passive: no fall damage and a little extra speed."),
    LIGHT("Light", 0xFFF1A8,
            "Holy radiance. Healing, protection and bane of the undead.",
            "Passive: blessed with good luck."),
    LIGHTNING("Lightning", 0xFFD21F,
            "Lightning fast. Chain strikes, stuns and storms.",
            "Passive: immune to lightning, faster hands (Haste)."),
    DARK("Dark", 0x8A3FD1,
            "Forbidden shadow. Curses, drain and the void itself.",
            "Passive: night vision when standing in darkness.");

    public final String displayName;
    public final int color;
    public final String description;
    public final String passive;
    private final Vector3f rgb;

    Element(String displayName, int color, String description, String passive) {
        this.displayName = displayName;
        this.color = color;
        this.description = description;
        this.passive = passive;
        this.rgb = new Vector3f(((color >> 16) & 255) / 255f, ((color >> 8) & 255) / 255f, (color & 255) / 255f);
    }

    public String id() {
        return name().toLowerCase(Locale.ROOT);
    }

    public Vector3f rgb() {
        return rgb;
    }

    public int argb() {
        return 0xFF000000 | color;
    }

    public static Element byOrdinal(int i) {
        Element[] v = values();
        return i >= 0 && i < v.length ? v[i] : FIRE;
    }
}
