package com.yash.magicalquest.network;

import com.yash.magicalquest.client.ClientHooks;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> client: open the element selection screen (rebirth = changing element later). */
public record OpenElementSelectPacket(boolean rebirth) {
    public static void encode(OpenElementSelectPacket msg, FriendlyByteBuf buf) {
        buf.writeBoolean(msg.rebirth);
    }

    public static OpenElementSelectPacket decode(FriendlyByteBuf buf) {
        return new OpenElementSelectPacket(buf.readBoolean());
    }

    public static void handle(OpenElementSelectPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.openElementSelect(msg.rebirth)));
        ctx.get().setPacketHandled(true);
    }
}
