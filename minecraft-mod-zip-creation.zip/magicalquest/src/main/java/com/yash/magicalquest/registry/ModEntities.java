package com.yash.magicalquest.registry;

import com.yash.magicalquest.MagicalQuest;
import com.yash.magicalquest.entity.MageEntity;
import com.yash.magicalquest.entity.MagicProjectile;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MagicalQuest.MODID);

    public static final RegistryObject<EntityType<MageEntity>> MAGE = ENTITIES.register("mage",
            () -> EntityType.Builder.of(MageEntity::new, MobCategory.CREATURE)
                    .sized(0.6f, 1.95f)
                    .clientTrackingRange(10)
                    .build(MagicalQuest.MODID + ":mage"));

    public static final RegistryObject<EntityType<MagicProjectile>> MAGIC_PROJECTILE = ENTITIES.register("magic_projectile",
            () -> EntityType.Builder.<MagicProjectile>of(MagicProjectile::new, MobCategory.MISC)
                    .sized(0.4f, 0.4f)
                    .clientTrackingRange(8)
                    .updateInterval(2)
                    .build(MagicalQuest.MODID + ":magic_projectile"));

    private ModEntities() {
    }
}
