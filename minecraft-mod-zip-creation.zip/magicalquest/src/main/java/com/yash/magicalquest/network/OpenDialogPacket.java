package com.yash.magicalquest.network;

import com.yash.magicalquest.client.ClientHooks;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/**
 * Server -> client: open a story dialogue.
 * mode 0 = just talking, mode 1 = quest offer (Accept / Not now buttons on the last page).
 */
public record OpenDialogPacket(int entityId, String speaker, List<String> pages, int mode, String questId) {
    public static void encode(OpenDialogPacket msg, FriendlyByteBuf buf) {
        buf.writeVarInt(msg.entityId);
        buf.writeUtf(msg.speaker);
        buf.writeVarInt(msg.pages.size());
        for (String page : msg.pages) {
            buf.writeUtf(page, 2048);
        }
        buf.writeVarInt(msg.mode);
        buf.writeUtf(msg.questId);
    }

    public static OpenDialogPacket decode(FriendlyByteBuf buf) {
        int entityId = buf.readVarInt();
        String speaker = buf.readUtf();
        int n = buf.readVarInt();
        List<String> pages = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            pages.add(buf.readUtf(2048));
        }
        int mode = buf.readVarInt();
        String questId = buf.readUtf();
        return new OpenDialogPacket(entityId, speaker, pages, mode, questId);
    }

    public static void handle(OpenDialogPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.openDialog(msg)));
        ctx.get().setPacketHandled(true);
    }
}
