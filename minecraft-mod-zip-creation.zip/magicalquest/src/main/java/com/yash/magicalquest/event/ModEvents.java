package com.yash.magicalquest.event;

import com.yash.magicalquest.MagicalQuest;
import com.yash.magicalquest.entity.MageEntity;
import com.yash.magicalquest.magic.PlayerMagic;
import com.yash.magicalquest.registry.ModEntities;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Mod-bus events shared by client and server. */
@Mod.EventBusSubscriber(modid = MagicalQuest.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModEvents {
    private ModEvents() {
    }

    @SubscribeEvent
    public static void registerCaps(RegisterCapabilitiesEvent event) {
        event.register(PlayerMagic.class);
    }

    @SubscribeEvent
    public static void attributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.MAGE.get(), MageEntity.createAttributes().build());
    }
}
