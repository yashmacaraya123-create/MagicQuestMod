package com.yash.magicalquest.client;

import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

public final class ClientKeys {
    public static final String CATEGORY = "key.categories.magicalquest";

    /** Hold to open the skill wheel, release to confirm. */
    public static final KeyMapping WHEEL = new KeyMapping("key.magicalquest.wheel", GLFW.GLFW_KEY_R, CATEGORY);
    /** Cast the selected skill. */
    public static final KeyMapping CAST = new KeyMapping("key.magicalquest.cast", GLFW.GLFW_KEY_Z, CATEGORY);
    /** Open the status / quest screen. */
    public static final KeyMapping STATUS = new KeyMapping("key.magicalquest.status", GLFW.GLFW_KEY_K, CATEGORY);

    private ClientKeys() {
    }
}
