package com.yash.magicalquest.skill;

import com.yash.magicalquest.MagicalQuest;
import com.yash.magicalquest.element.Element;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;

import java.util.Locale;

/** A castable magical skill. */
public final class Skill {
    /** Icon shapes. Every element has exactly one skill per icon. */
    public enum Icon { ORB, DASH, NOVA, BEAM, SHIELD, HEART, SPIKE, WARP, VORTEX, SUN }

    @FunctionalInterface
    public interface Caster {
        void cast(ServerPlayer player, Skill skill);
    }

    public final String id;
    public final Element element;
    public final int index;
    public final String name;
    public final String description;
    public final int manaCost;
    public final int cooldown;
    public final Icon icon;
    public final Caster caster;

    public Skill(String id, Element element, int index, String name, String description,
                 int manaCost, int cooldown, Icon icon, Caster caster) {
        this.id = id;
        this.element = element;
        this.index = index;
        this.name = name;
        this.description = description;
        this.manaCost = manaCost;
        this.cooldown = cooldown;
        this.icon = icon;
        this.caster = caster;
    }

    public ResourceLocation iconTexture() {
        return new ResourceLocation(MagicalQuest.MODID,
                "textures/gui/skill/" + element.id() + "_" + icon.name().toLowerCase(Locale.ROOT) + ".png");
    }
}
