package com.yash.magicalquest.network;

import com.yash.magicalquest.MagicalQuest;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.Optional;

public final class Net {
    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(MagicalQuest.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private Net() {
    }

    public static void init() {
        int id = 0;
        // server -> client
        CHANNEL.registerMessage(id++, SyncMagicPacket.class, SyncMagicPacket::encode, SyncMagicPacket::decode,
                SyncMagicPacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(id++, OpenElementSelectPacket.class, OpenElementSelectPacket::encode, OpenElementSelectPacket::decode,
                OpenElementSelectPacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(id++, OpenDialogPacket.class, OpenDialogPacket::encode, OpenDialogPacket::decode,
                OpenDialogPacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        // client -> server
        CHANNEL.registerMessage(id++, ChooseElementPacket.class, ChooseElementPacket::encode, ChooseElementPacket::decode,
                ChooseElementPacket::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(id++, SelectSkillPacket.class, SelectSkillPacket::encode, SelectSkillPacket::decode,
                SelectSkillPacket::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(id++, CastSkillPacket.class, CastSkillPacket::encode, CastSkillPacket::decode,
                CastSkillPacket::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(id++, AcceptQuestPacket.class, AcceptQuestPacket::encode, AcceptQuestPacket::decode,
                AcceptQuestPacket::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(id++, AbandonQuestPacket.class, AbandonQuestPacket::encode, AbandonQuestPacket::decode,
                AbandonQuestPacket::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
    }

    public static void toPlayer(ServerPlayer player, Object message) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), message);
    }

    public static void toServer(Object message) {
        CHANNEL.sendToServer(message);
    }
}
