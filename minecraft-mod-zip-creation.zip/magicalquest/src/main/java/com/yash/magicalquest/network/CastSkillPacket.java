package com.yash.magicalquest.network;

import com.yash.magicalquest.magic.SkillManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: cast the currently selected skill. */
public record CastSkillPacket() {
    public static void encode(CastSkillPacket msg, FriendlyByteBuf buf) {
    }

    public static CastSkillPacket decode(FriendlyByteBuf buf) {
        return new CastSkillPacket();
    }

    public static void handle(CastSkillPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player != null) {
                SkillManager.cast(player, 1.0f);
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
