package com.yash.magicalquest.network;

import com.yash.magicalquest.client.ClientHooks;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> client: the complete magic state of the local player. */
public record SyncMagicPacket(CompoundTag tag) {
    public static void encode(SyncMagicPacket msg, FriendlyByteBuf buf) {
        buf.writeNbt(msg.tag);
    }

    public static SyncMagicPacket decode(FriendlyByteBuf buf) {
        CompoundTag tag = buf.readNbt();
        return new SyncMagicPacket(tag == null ? new CompoundTag() : tag);
    }

    public static void handle(SyncMagicPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.sync(msg.tag)));
        ctx.get().setPacketHandled(true);
    }
}
