package com.yash.magicalquest.registry;

import com.yash.magicalquest.MagicalQuest;
import com.yash.magicalquest.element.Element;
import com.yash.magicalquest.item.CharmItem;
import com.yash.magicalquest.item.MageStaffItem;
import com.yash.magicalquest.item.ManaPotionItem;
import com.yash.magicalquest.item.RebirthCrystalItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.EnumMap;
import java.util.Map;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MagicalQuest.MODID);

    public static final RegistryObject<Item> REBIRTH_CRYSTAL = ITEMS.register("rebirth_crystal",
            () -> new RebirthCrystalItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));

    public static final RegistryObject<Item> MANA_POTION = ITEMS.register("mana_potion",
            () -> new ManaPotionItem(new Item.Properties().stacksTo(16)));

    public static final RegistryObject<Item> MANA_SHARD = ITEMS.register("mana_shard",
            () -> new Item(new Item.Properties().rarity(Rarity.UNCOMMON)));

    public static final RegistryObject<Item> MAGE_STAFF = ITEMS.register("mage_staff",
            () -> new MageStaffItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));

    public static final Map<Element, RegistryObject<Item>> CHARMS = new EnumMap<>(Element.class);

    static {
        for (Element e : Element.values()) {
            CHARMS.put(e, ITEMS.register("charm_" + e.id(),
                    () -> new CharmItem(e, new Item.Properties().stacksTo(1).rarity(Rarity.RARE))));
        }
    }

    public static final RegistryObject<Item> MAGE_SPAWN_EGG = ITEMS.register("mage_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.MAGE, 0x4A2A7A, 0xE6C34A, new Item.Properties()));

    private ModItems() {
    }
}
