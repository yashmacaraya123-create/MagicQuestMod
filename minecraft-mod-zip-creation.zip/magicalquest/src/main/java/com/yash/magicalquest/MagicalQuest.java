package com.yash.magicalquest;

import com.mojang.logging.LogUtils;
import com.yash.magicalquest.element.Element;
import com.yash.magicalquest.quest.Quests;
import com.yash.magicalquest.skill.Skills;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import com.yash.magicalquest.network.Net;
import com.yash.magicalquest.registry.ModEntities;
import com.yash.magicalquest.registry.ModItems;
import com.yash.magicalquest.registry.ModTabs;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

/**
 * Magical Quest - reborn into a world of magic.
 * Choose an element, accept quests from the Village Mage, unlock skills and grow into a legend.
 */
@Mod(MagicalQuest.MODID)
public class MagicalQuest {
    public static final String MODID = "magicalquest";
    public static final Logger LOGGER = LogUtils.getLogger();

    public MagicalQuest() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModTabs.TABS.register(bus);
        Net.init();
        bus.addListener(this::commonSetup);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        // Loading the registries here makes any definition error show up immediately at startup.
        int skills = Skills.all().size();
        int quests = Quests.all().size();
        for (Element e : Element.values()) {
            if (Skills.of(e).size() != 10) {
                throw new IllegalStateException(e + " must have exactly 10 skills");
            }
        }
        LOGGER.info("Magical Quest loaded: {} skills across {} elements, {} quests", skills, Element.values().length, quests);
    }
}
