package com.yash.magicalquest.network;

import com.yash.magicalquest.quest.QuestManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: abandon the active quest. */
public record AbandonQuestPacket() {
    public static void encode(AbandonQuestPacket msg, FriendlyByteBuf buf) {
    }

    public static AbandonQuestPacket decode(FriendlyByteBuf buf) {
        return new AbandonQuestPacket();
    }

    public static void handle(AbandonQuestPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player != null) {
                QuestManager.abandon(player);
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
