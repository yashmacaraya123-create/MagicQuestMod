package com.yash.magicalquest.event;

import com.yash.magicalquest.MagicalQuest;
import com.yash.magicalquest.element.Element;
import com.yash.magicalquest.entity.MageEntity;
import com.yash.magicalquest.item.CharmItem;
import com.yash.magicalquest.magic.MagicCaps;
import com.yash.magicalquest.magic.MagicProvider;
import com.yash.magicalquest.magic.PlayerMagic;
import com.yash.magicalquest.magic.SkillManager;
import com.yash.magicalquest.quest.QuestManager;
import com.yash.magicalquest.registry.ModEntities;
import com.yash.magicalquest.skill.Scheduler;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Gameplay events on the Forge bus (both sides unless noted). */
@Mod.EventBusSubscriber(modid = MagicalQuest.MODID)
public final class ServerEvents {
    private ServerEvents() {
    }

    // ------------------------------------------------------------- capability

    @SubscribeEvent
    public static void attach(AttachCapabilitiesEvent<Entity> event) {
        if (event.getObject() instanceof Player) {
            event.addCapability(new ResourceLocation(MagicalQuest.MODID, "magic"), new MagicProvider());
        }
    }

    @SubscribeEvent
    public static void clone(PlayerEvent.Clone event) {
        event.getOriginal().reviveCaps();
        event.getOriginal().getCapability(MagicCaps.MAGIC).ifPresent(old ->
                event.getEntity().getCapability(MagicCaps.MAGIC).ifPresent(now -> now.copyFrom(old)));
        event.getOriginal().invalidateCaps();
    }

    // ----------------------------------------------------------------- joining

    @SubscribeEvent
    public static void login(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) {
            PlayerMagic.get(sp).rebirthPending = false;
            MagicCaps.sync(sp);
            SkillManager.promptIfNeeded(sp);
        }
    }

    @SubscribeEvent
    public static void respawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) {
            PlayerMagic m = PlayerMagic.get(sp);
            m.mana = m.maxMana();
            MagicCaps.sync(sp);
            SkillManager.promptIfNeeded(sp);
        }
    }

    @SubscribeEvent
    public static void dimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) {
            MagicCaps.sync(sp);
        }
    }

    // -------------------------------------------------------------------- ticks

    @SubscribeEvent
    public static void playerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        Player player = event.player;
        PlayerMagic m = PlayerMagic.get(player);

        if (!m.cooldowns.isEmpty()) {
            m.cooldowns.entrySet().removeIf(e -> {
                e.setValue(e.getValue() - 1);
                return e.getValue() <= 0;
            });
        }

        if (player.level().isClientSide || !(player instanceof ServerPlayer sp) || !m.chosen) {
            return;
        }

        float max = m.maxMana();
        if (m.mana < max) {
            float regen = 0.12f * (m.hasCharm ? 1.5f : 1f) * (sp.isShiftKeyDown() ? 2f : 1f);
            m.mana = Math.min(max, m.mana + regen);
            m.manaDirty = true;
        } else if (m.mana > max) {
            m.mana = max;
        }
        int t = sp.tickCount;
        if (t % 10 == 0 && m.manaDirty) {
            m.manaDirty = false;
            MagicCaps.sync(sp);
        }
        if (t % 40 == 0) {
            m.hasCharm = hasMatchingCharm(sp, m.element);
            applyPassives(sp, m);
            QuestManager.tickExplore(sp);
            QuestManager.tickCollect(sp);
        }
    }

    @SubscribeEvent
    public static void serverTick(TickEvent.ServerTickEvent event) {
        if (event.phase == TickEvent.Phase.END) {
            Scheduler.tick();
        }
    }

    @SubscribeEvent
    public static void serverStopped(ServerStoppedEvent event) {
        Scheduler.clear();
    }

    private static boolean hasMatchingCharm(ServerPlayer sp, Element element) {
        for (int i = 0; i < sp.getInventory().getContainerSize(); i++) {
            ItemStack st = sp.getInventory().getItem(i);
            if (st.getItem() instanceof CharmItem c && c.element == element) {
                return true;
            }
        }
        return false;
    }

    private static void give(ServerPlayer sp, MobEffect effect, int amp, int duration) {
        sp.addEffect(new MobEffectInstance(effect, duration, amp, true, false, true));
    }

    private static void applyPassives(ServerPlayer sp, PlayerMagic m) {
        int amp = m.hasCharm ? 1 : 0;
        switch (m.element) {
            case FIRE -> give(sp, MobEffects.FIRE_RESISTANCE, 0, 140);
            case WATER -> {
                if (sp.isInWater()) {
                    give(sp, MobEffects.WATER_BREATHING, 0, 140);
                    give(sp, MobEffects.DOLPHINS_GRACE, 0, 140);
                }
            }
            case EARTH -> give(sp, MobEffects.HEALTH_BOOST, amp, 140);
            case WIND -> give(sp, MobEffects.MOVEMENT_SPEED, 0, 140);
            case LIGHT -> give(sp, MobEffects.LUCK, amp, 140);
            case LIGHTNING -> give(sp, MobEffects.DIG_SPEED, amp, 140);
            case DARK -> {
                if (sp.level().getMaxLocalRawBrightness(sp.blockPosition()) <= 4) {
                    give(sp, MobEffects.NIGHT_VISION, 0, 260);
                }
            }
        }
    }

    // ------------------------------------------------------------ passive events

    @SubscribeEvent
    public static void fall(LivingFallEvent event) {
        if (event.getEntity() instanceof Player p) {
            PlayerMagic m = PlayerMagic.get(p);
            if (m.chosen && m.element == Element.WIND) {
                event.setCanceled(true);
            }
        }
    }

    @SubscribeEvent
    public static void attacked(LivingAttackEvent event) {
        if (event.getEntity() instanceof Player p && event.getSource().is(DamageTypes.LIGHTNING_BOLT)) {
            PlayerMagic m = PlayerMagic.get(p);
            if (m.chosen && m.element == Element.LIGHTNING) {
                event.setCanceled(true);
            }
        }
    }

    // ------------------------------------------------------------- quest hooks

    @SubscribeEvent
    public static void kill(LivingDeathEvent event) {
        if (event.getSource().getEntity() instanceof ServerPlayer sp && event.getEntity() != sp) {
            QuestManager.onKill(sp, event.getEntity().getType());
        }
    }

    @SubscribeEvent
    public static void mine(BlockEvent.BreakEvent event) {
        if (event.getPlayer() instanceof ServerPlayer sp) {
            QuestManager.onMine(sp, event.getState());
        }
    }

    @SubscribeEvent
    public static void place(BlockEvent.EntityPlaceEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) {
            QuestManager.onPlace(sp, event.getPlacedBlock());
        }
    }

    @SubscribeEvent
    public static void craft(PlayerEvent.ItemCraftedEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) {
            QuestManager.onCraft(sp, event.getCrafting());
        }
    }

    // ------------------------------------------------------- mages in villages

    @SubscribeEvent
    public static void villagerJoin(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide() || !(event.getEntity() instanceof Villager villager) || villager.isBaby()) {
            return;
        }
        if (villager.getPersistentData().getBoolean("mq_checked")) {
            return;
        }
        villager.getPersistentData().putBoolean("mq_checked", true);
        if (!(event.getLevel() instanceof ServerLevel level) || level.random.nextInt(5) != 0) {
            return;
        }
        // Spawn on the next tick so we never add entities while another entity is being added.
        Scheduler.later(2, () -> {
            if (!villager.isAlive() || !level.isLoaded(villager.blockPosition())) {
                return;
            }
            if (!level.getEntitiesOfClass(MageEntity.class, villager.getBoundingBox().inflate(80)).isEmpty()) {
                return;
            }
            MageEntity mage = ModEntities.MAGE.get().create(level);
            if (mage == null) {
                return;
            }
            Vec3 pos = villager.position();
            mage.moveTo(pos.x + 1.5, pos.y, pos.z + 0.5, level.random.nextFloat() * 360f, 0f);
            mage.finalizeSpawn(level, level.getCurrentDifficultyAt(villager.blockPosition()), MobSpawnType.STRUCTURE, null, null);
            level.addFreshEntity(mage);
        });
    }
}
