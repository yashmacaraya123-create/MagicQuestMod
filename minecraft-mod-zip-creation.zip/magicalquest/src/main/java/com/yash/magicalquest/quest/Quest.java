package com.yash.magicalquest.quest;

import com.yash.magicalquest.element.Element;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;

/** A single quest definition. Targets are comma separated ids; a leading '#' means a tag. */
public final class Quest {
    public record Reward(String label, Function<Element, ItemStack> make) {
    }

    public final String id;
    public final String title;
    public final Element element; // null = available to every element
    public final int minCompleted;
    public final QuestType type;
    public final List<String> targets;
    public final int count;
    public final String goal;
    public final List<String> story;
    public final String done;

    public int rewardSkillIndex = 0;
    public int rewardXp = 50;
    public final List<Reward> rewards = new ArrayList<>();

    public Quest(String id, String title, Element element, int minCompleted, QuestType type, String targets,
                 int count, String goal, String story, String done) {
        this.id = id;
        this.title = title;
        this.element = element;
        this.minCompleted = minCompleted;
        this.type = type;
        this.targets = Arrays.stream(targets.split(",")).map(String::trim).toList();
        this.count = count;
        this.goal = goal;
        this.story = Arrays.stream(story.split("\\|")).map(String::trim).toList();
        this.done = done;
    }

    public Quest reward(String label, Function<Element, ItemStack> make) {
        rewards.add(new Reward(label, make));
        return this;
    }

    public Quest xp(int xp) {
        this.rewardXp = xp;
        return this;
    }

    public String objective(int progress) {
        if (type == QuestType.EXPLORE) {
            return "Discover: " + goal + " (" + Math.min(progress, count) + "/" + count + ")";
        }
        return type.verb + " " + count + " " + goal + ": " + Math.min(progress, count) + "/" + count;
    }

    // ---------------------------------------------------------------- matchers

    private static ResourceLocation rl(String s) {
        return new ResourceLocation(s);
    }

    public boolean matchesEntity(EntityType<?> t) {
        ResourceLocation key = EntityType.getKey(t);
        for (String s : targets) {
            if (s.startsWith("#")) {
                if (t.is(TagKey.create(Registries.ENTITY_TYPE, rl(s.substring(1))))) {
                    return true;
                }
            } else if (key.toString().equals(s)) {
                return true;
            }
        }
        return false;
    }

    public boolean matchesBlock(BlockState state) {
        ResourceLocation key = ForgeRegistries.BLOCKS.getKey(state.getBlock());
        for (String s : targets) {
            if (s.startsWith("#")) {
                if (state.is(TagKey.create(Registries.BLOCK, rl(s.substring(1))))) {
                    return true;
                }
            } else if (key != null && key.toString().equals(s)) {
                return true;
            }
        }
        return false;
    }

    public boolean matchesItem(ItemStack stack) {
        if (stack.isEmpty()) {
            return false;
        }
        ResourceLocation key = ForgeRegistries.ITEMS.getKey(stack.getItem());
        for (String s : targets) {
            if (s.startsWith("#")) {
                if (stack.is(TagKey.create(Registries.ITEM, rl(s.substring(1))))) {
                    return true;
                }
            } else if (key != null && key.toString().equals(s)) {
                return true;
            }
        }
        return false;
    }

    public boolean matchesBiome(Holder<Biome> biome) {
        Optional<ResourceKey<Biome>> key = biome.unwrapKey();
        if (key.isEmpty()) {
            return false;
        }
        String id = key.get().location().toString();
        for (String s : targets) {
            if (s.equals(id)) {
                return true;
            }
        }
        return false;
    }
}
