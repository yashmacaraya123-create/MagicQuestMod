package com.yash.magicalquest.client.render;

import com.yash.magicalquest.MagicalQuest;
import com.yash.magicalquest.client.model.MageModel;
import com.yash.magicalquest.entity.MageEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class MageRenderer extends MobRenderer<MageEntity, MageModel> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(MagicalQuest.MODID, "textures/entity/mage.png");

    public MageRenderer(EntityRendererProvider.Context context) {
        super(context, new MageModel(context.bakeLayer(MageModel.LAYER)), 0.45f);
    }

    @Override
    public ResourceLocation getTextureLocation(MageEntity entity) {
        return TEXTURE;
    }
}
