package com.yash.magicalquest.client.screen;

import com.yash.magicalquest.MagicalQuest;
import com.yash.magicalquest.client.ClientText;
import com.yash.magicalquest.element.Element;
import com.yash.magicalquest.network.ChooseElementPacket;
import com.yash.magicalquest.network.Net;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import java.util.Random;

/** The Goddess scene: a short reincarnation intro followed by the element choice. */
public class ElementSelectScreen extends Screen {
    private static final int CW = 104;
    private static final int CH = 106;
    private static final int GAP = 8;

    private static final String[] INTRO = {
            "...Where... am I?",
            "You remember a screech of tires. A flash of light. Then nothing at all.\n\nYou died.",
            "But your story does not end here. A warm voice echoes through the endless dark...",
            "\"Brave soul... I am the Goddess of this world. A great darkness is stirring, and I have chosen you to stand against it.\"",
            "\"Magic flows through everything here. Choose the element that will define your new life. Choose well: only a Rebirth Crystal can ever change it.\""
    };
    private static final String[] REBIRTH_INTRO = {
            "The Rebirth Crystal shatters into motes of light, and the threads of your fate begin to unravel...",
            "\"Choose again, reborn one. A new element will rewrite who you are.\""
    };

    private final boolean rebirth;
    private final String[] intro;
    private int page;
    private float chars;
    private int ticks;
    private boolean choosing;
    private boolean sent;
    private Element selected;
    private Button confirm;
    private Button cancel;

    public ElementSelectScreen(boolean rebirth) {
        super(Component.literal("Choose your element"));
        this.rebirth = rebirth;
        this.intro = rebirth ? REBIRTH_INTRO : INTRO;
    }

    private int top() {
        return Math.max(34, (height - (2 * CH + GAP + 64)) / 2 + 22);
    }

    private int[] cardPos(int i) {
        int row = i < 4 ? 0 : 1;
        int count = row == 0 ? 4 : 3;
        int idx = row == 0 ? i : i - 4;
        int totalW = count * CW + (count - 1) * GAP;
        return new int[]{(width - totalW) / 2 + idx * (CW + GAP), top() + row * (CH + GAP)};
    }

    @Override
    protected void init() {
        int by = top() + 2 * CH + GAP + 8;
        if (rebirth) {
            cancel = addRenderableWidget(Button.builder(Component.literal("Keep my element"), b -> onClose())
                    .bounds(width / 2 - 155, by, 150, 20).build());
            confirm = addRenderableWidget(Button.builder(Component.literal("Be reborn"), b -> confirm())
                    .bounds(width / 2 + 5, by, 150, 20).build());
        } else {
            confirm = addRenderableWidget(Button.builder(Component.literal("Awaken"), b -> confirm())
                    .bounds(width / 2 - 75, by, 150, 20).build());
        }
        confirm.active = selected != null;
        confirm.visible = choosing;
        if (cancel != null) {
            cancel.visible = choosing;
        }
    }

    private void confirm() {
        if (selected == null) {
            return;
        }
        sent = true;
        Net.toServer(new ChooseElementPacket(selected.ordinal()));
        Minecraft.getInstance().setScreen(null);
    }

    @Override
    public void onClose() {
        if (rebirth && !sent) {
            sent = true;
            Net.toServer(new ChooseElementPacket(-1));
        }
        super.onClose();
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return rebirth;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void tick() {
        ticks++;
        if (!choosing) {
            chars += 1.6f;
        }
    }

    private void advance() {
        String text = intro[page];
        if (chars < text.length()) {
            chars = text.length();
            return;
        }
        page++;
        chars = 0;
        if (page >= intro.length) {
            page = intro.length - 1;
            choosing = true;
            confirm.visible = true;
            if (cancel != null) {
                cancel.visible = true;
            }
        }
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (!choosing && (key == GLFW.GLFW_KEY_SPACE || key == GLFW.GLFW_KEY_ENTER)) {
            advance();
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (!choosing) {
            advance();
            return true;
        }
        if (super.mouseClicked(mx, my, button)) {
            return true;
        }
        Element[] all = Element.values();
        for (int i = 0; i < all.length; i++) {
            int[] p = cardPos(i);
            if (mx >= p[0] && mx < p[0] + CW && my >= p[1] && my < p[1] + CH) {
                selected = all[i];
                confirm.active = true;
                Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0f));
                return true;
            }
        }
        return false;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        g.fillGradient(0, 0, width, height, 0xF0070312, 0xF01A0B35);
        Random rnd = new Random(42);
        for (int i = 0; i < 70; i++) {
            int sx = rnd.nextInt(Math.max(1, width));
            int sy = rnd.nextInt(Math.max(1, height));
            int a = (int) (90 + 80 * Math.sin((ticks + pt) * 0.08 + i));
            g.fill(sx, sy, sx + 1, sy + 1, (Math.max(20, Math.min(255, a)) << 24) | 0xFFFFFF);
        }
        if (!choosing) {
            renderIntro(g);
        } else {
            renderChoose(g, mx, my);
        }
        super.render(g, mx, my, pt);
    }

    private void renderIntro(GuiGraphics g) {
        String text = intro[page];
        List<String> lines = ClientText.wrap(font, text, Math.min(340, width - 40));
        int y = height / 2 - lines.size() * 6;
        ClientText.drawTyped(g, font, lines, 0, y, 12, 0xFFE8DDFF, (int) chars, true, width / 2);
        if (chars >= text.length()) {
            int c = (ticks / 10) % 2 == 0 ? 0xFF9A8CC0 : 0xFF5A4E80;
            g.drawCenteredString(font, "Click to continue", width / 2, height - 36, c);
        }
    }

    private void renderChoose(GuiGraphics g, int mx, int my) {
        g.drawCenteredString(font, rebirth ? "Choose your new element" : "Choose your element", width / 2, 10, 0xFFFFFFFF);
        if (selected != null) {
            g.drawCenteredString(font, selected.displayName + " - " + selected.passive, width / 2, 22, selected.argb());
        } else {
            g.drawCenteredString(font, "Click an element to see its gift.", width / 2, 22, 0xFF8F84AE);
        }
        Element[] all = Element.values();
        for (int i = 0; i < all.length; i++) {
            Element e = all[i];
            int[] p = cardPos(i);
            int x = p[0];
            int y = p[1];
            boolean hover = mx >= x && mx < x + CW && my >= y && my < y + CH;
            boolean sel = e == selected;
            int border = sel ? 0xFFFFFFFF : hover ? e.argb() : 0xFF3A2F5C;
            g.fill(x - 1, y - 1, x + CW + 1, y + CH + 1, border);
            if (sel) {
                g.fill(x - 2, y - 2, x + CW + 2, y + CH + 2, 0x55000000 | e.color);
                g.fill(x - 1, y - 1, x + CW + 1, y + CH + 1, border);
            }
            g.fill(x, y, x + CW, y + CH, 0xFF120A24);
            g.fillGradient(x, y, x + CW, y + 44, 0x66000000 | e.color, 0x00000000 | e.color);
            ResourceLocation icon = new ResourceLocation(MagicalQuest.MODID, "textures/gui/skill/" + e.id() + "_orb.png");
            g.blit(icon, x + CW / 2 - 16, y + 6, 32, 32, 0f, 0f, 16, 16, 16, 16);
            g.drawCenteredString(font, e.displayName, x + CW / 2, y + 42, e.argb());
            List<String> desc = ClientText.wrap(font, e.description, CW - 10);
            int ty = y + 55;
            for (String line : desc) {
                g.drawString(font, line, x + 5, ty, 0xFFB5ABD0, false);
                ty += 10;
            }
        }
    }
}
