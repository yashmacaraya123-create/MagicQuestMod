package com.yash.magicalquest.magic;

import com.yash.magicalquest.network.Net;
import com.yash.magicalquest.network.SyncMagicPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;

public final class MagicCaps {
    public static final Capability<PlayerMagic> MAGIC = CapabilityManager.get(new CapabilityToken<>() {
    });

    private MagicCaps() {
    }

    /** Sends the full magic state of a player to their client. */
    public static void sync(ServerPlayer player) {
        Net.toPlayer(player, new SyncMagicPacket(PlayerMagic.get(player).save()));
    }
}
