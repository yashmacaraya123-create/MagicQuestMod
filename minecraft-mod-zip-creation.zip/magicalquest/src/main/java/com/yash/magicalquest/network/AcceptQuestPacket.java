package com.yash.magicalquest.network;

import com.yash.magicalquest.quest.QuestManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: accept the quest offered by the Mage. */
public record AcceptQuestPacket(String questId) {
    public static void encode(AcceptQuestPacket msg, FriendlyByteBuf buf) {
        buf.writeUtf(msg.questId);
    }

    public static AcceptQuestPacket decode(FriendlyByteBuf buf) {
        return new AcceptQuestPacket(buf.readUtf());
    }

    public static void handle(AcceptQuestPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player != null) {
                QuestManager.accept(player, msg.questId);
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
