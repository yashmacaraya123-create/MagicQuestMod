package com.yash.magicalquest.quest;

import com.yash.magicalquest.element.Element;
import com.yash.magicalquest.registry.ModItems;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static com.yash.magicalquest.quest.QuestType.*;

/**
 * Every quest in the mod. General quests come first (they are offered as soon as the player has
 * completed enough quests); every element then has a chain of 9 quests that unlock skills #2-#10.
 */
public final class Quests {
    private static final Map<String, Quest> BY_ID = new LinkedHashMap<>();
    private static final List<Quest> ORDERED = new ArrayList<>();
    private static final Map<Element, Integer> CHAIN_COUNT = new EnumMap<>(Element.class);

    static {
        general();
        fire();
        water();
        earth();
        wind();
        light();
        lightning();
        dark();
    }

    private Quests() {
    }

    public static Quest get(String id) {
        return id == null || id.isEmpty() ? null : BY_ID.get(id);
    }

    public static List<Quest> all() {
        return Collections.unmodifiableList(ORDERED);
    }

    private static Quest add(Quest q) {
        BY_ID.put(q.id, q);
        ORDERED.add(q);
        return q;
    }

    private static Quest chain(Element e, String title, QuestType type, String targets, int count, String goal,
                               String story, String done) {
        int n = CHAIN_COUNT.merge(e, 1, Integer::sum);
        Quest q = new Quest(e.id() + "_" + n, title, e, 0, type, targets, count, goal, story, done);
        q.rewardSkillIndex = n;
        q.rewardXp = 40 + n * 25;
        return add(q);
    }

    private static Quest gen(String id, int minCompleted, String title, QuestType type, String targets, int count,
                             String goal, String story, String done) {
        return add(new Quest(id, title, null, minCompleted, type, targets, count, goal, story, done));
    }

    private static ItemStack stack(net.minecraft.world.item.Item item, int n) {
        return new ItemStack(item, n);
    }

    // ================================================================ GENERAL
    private static void general() {
        gen("g_reborn_soul", 0, "A Reborn Soul", COLLECT, "#minecraft:logs", 16, "Logs",
                "Ah... your aura is strange. It flickers like a candle standing between two worlds.|"
                        + "You are a reborn soul, aren't you? Do not be afraid. The Goddess sends one of you whenever the darkness stirs.|"
                        + "Before I teach you the ways of magic, prove you can survive. Bring me sixteen logs, and I will light you a proper fire for your first night.",
                "Good work! This warmth... this is how every legend begins. Take these Mana Potions. You will need them.")
                .reward("3x Mana Potion", e -> stack(ModItems.MANA_POTION.get(), 3)).xp(60);

        gen("g_trial_resolve", 3, "Trial of Resolve", KILL, "minecraft:skeleton,minecraft:stray", 10, "Skeletons",
                "You have grown, reborn one. But magic without a focus is like a river without a bed.|"
                        + "The skeletons that roam at night carry bones imbued with old mana. Defeat ten of them and I will give you something to channel it through.",
                "Ten fallen, and not a scratch on you? Take this staff. It sharpens your casting and makes every spell cheaper.")
                .reward("Mage Staff", e -> stack(ModItems.MAGE_STAFF.get(), 1))
                .reward("4x Mana Shard", e -> stack(ModItems.MANA_SHARD.get(), 4)).xp(150);

        gen("g_home", 4, "A Place to Call Home", BUILD, "#minecraft:planks", 80, "Planks",
                "A traveller without a home is just a wanderer, and a wanderer's mana scatters like leaves in the wind.|"
                        + "Build yourself a home. Eighty planks should do. Give your spirit somewhere to rest.",
                "A fine roof! Now your mana has somewhere to settle. Here, something for the long nights.")
                .reward("6x Mana Shard", e -> stack(ModItems.MANA_SHARD.get(), 6))
                .reward("3x Mana Potion", e -> stack(ModItems.MANA_POTION.get(), 3)).xp(120);

        gen("g_element_echo", 5, "Echo of the Element", COLLECT, "minecraft:amethyst_shard", 8, "Amethyst Shards",
                "Every element leaves an echo, a faint song in crystal. Amethyst hears it best.|"
                        + "Bring me eight amethyst shards from the geodes beneath the earth, and I will bind your element's echo into a charm.",
                "Listen... can you hear it hum? That is your element, singing back to you. Carry this charm always.")
                .reward("Elemental Charm", e -> stack(ModItems.CHARMS.get(e).get(), 1)).xp(200);

        gen("g_threads_fate", 8, "The Threads of Fate", COLLECT, "minecraft:diamond", 5, "Diamonds",
                "The Goddess weaves each soul's thread by hand. Sometimes a soul wishes it had chosen another path.|"
                        + "I can craft a Rebirth Crystal that lets you rewrite your element, but it needs five diamonds to hold such power.",
                "Remarkable. A crystal that holds a whole second life. Use it wisely, for every rebirth rewrites who you are.")
                .reward("Rebirth Crystal", e -> stack(ModItems.REBIRTH_CRYSTAL.get(), 1)).xp(300);

        gen("g_demon_shadow", 12, "The Demon Lord's Shadow", KILL, "minecraft:enderman", 12, "Endermen",
                "I have had dreams, reborn one. Dreams of a throne in the void and a shadow that grows with every year.|"
                        + "The Endermen are its eyes. Strike down twelve of them and perhaps it will look away from our world... for a time.|"
                        + "Great evils are waking. More will be asked of you before the end.",
                "The shadow stirs, but you stood tall. Keep these. The road ahead only gets harder.")
                .reward("5x Mana Potion", e -> stack(ModItems.MANA_POTION.get(), 5))
                .reward("8x Mana Shard", e -> stack(ModItems.MANA_SHARD.get(), 8)).xp(400);
    }

    // =================================================================== FIRE
    private static void fire() {
        Element E = Element.FIRE;
        chain(E, "Kindling the Flame", COLLECT, "minecraft:coal", 16, "Coal",
                "Fire is the oldest magic, the first spark that ever lit the dark.|To awaken yours, you must feed it. Gather sixteen pieces of coal and bring them to me.",
                "Good. Do you feel that warmth in your chest? That is your flame speaking. It will never go out again.");
        chain(E, "Trial of Cinders", KILL, "minecraft:zombie,minecraft:husk", 10, "Zombies or Husks",
                "The restless dead walk at night, and fire is the thing they fear most.|Burn ten of them away and your flame will learn to bite.",
                "Ashes and silence. Your fire has tasted battle, and it hungers for more.");
        chain(E, "Heart of the Furnace", MINE, "minecraft:iron_ore,minecraft:deepslate_iron_ore", 12, "Iron Ore",
                "A fire mage who cannot work metal is only half a mage.|Dig twelve iron ores from the deep places. Fire and iron make the finest steel.",
                "Fine ore! Your flame will shape it like clay now.");
        chain(E, "Ash and Bone", KILL, "minecraft:skeleton,minecraft:stray", 12, "Skeletons",
                "Skeletons rattle through the dark with arrows full of malice. Twelve of them have been harassing my villagers.|Show them what true fire can do.",
                "Bones turned to ash. The villagers will sleep soundly tonight.");
        chain(E, "Forge of the Reborn", CRAFT, "minecraft:blast_furnace", 1, "a Blast Furnace",
                "A mage's fire needs a home. Build a blast furnace and let it burn with your own flame.",
                "Look at it roar! A forge that answers to its master. Your fire grows deeper.");
        chain(E, "Walk the Scorched Land", EXPLORE, "minecraft:desert", 1, "a Desert",
                "The desert is where the sun shows its true face. Travel there and let its heat temper your soul.",
                "You walked the burning sands and came back stronger. The sun itself is proud.");
        chain(E, "Blaze Hunter", KILL, "minecraft:blaze", 6, "Blazes",
                "Beyond the burning gates of the Nether, the Blazes dance in living flame.|Six of them must fall, to prove that your fire is greater than theirs.",
                "Dancing flames put out by a greater one. Your fire is no longer a spark, but a blaze.");
        chain(E, "Cinder Knights", KILL, "minecraft:wither_skeleton", 4, "Wither Skeletons",
                "In the fortress ruins stand the Cinder Knights, black bones that remember no mercy.|Defeat four and you earn the right to the final flame.",
                "The knights are cinders. Only one trial remains.");
        chain(E, "Crown of Inferno", KILL, "minecraft:wither", 1, "the Wither",
                "There is a being of pure ruin that can be summoned with three skulls and a bed of soul sand: the Wither.|Destroy it, and the flame of the Phoenix will crown you.",
                "Impossible... and yet you stand. The ultimate fire is yours, reborn one.");
    }

    // ================================================================== WATER
    private static void water() {
        Element E = Element.WATER;
        chain(E, "First Drop", COLLECT, "#minecraft:fishes", 8, "Fish",
                "Water remembers everything, and it never forgets a kindness.|Bring me eight fish from the river and we shall begin.",
                "Wonderful. The river speaks well of you.");
        chain(E, "River's Memory", MINE, "minecraft:clay", 16, "Clay Blocks",
                "Rivers carve their memories into the clay beneath them.|Dig sixteen blocks of it and learn to feel the water's story.",
                "Cool and smooth. You can hear it now, can't you? The river's old songs.");
        chain(E, "Drowned Lament", KILL, "minecraft:drowned", 10, "Drowned",
                "The drowned wail beneath the waves, souls that never found the shore.|Release ten of them, gently if you can.",
                "They are at peace now. The water thanks you.");
        chain(E, "Vessel of the Tide", CRAFT, "#minecraft:boats", 1, "a Boat",
                "A water mage must learn to trust the tide. Build a boat and sail a river.|A vessel is a promise to the sea.",
                "A promise made. The sea will remember it.");
        chain(E, "Frozen Whispers", EXPLORE, "minecraft:snowy_plains", 1, "Snowy Plains",
                "Water sleeps in the snow. Walk the snowy plains and listen. You will hear it dreaming.",
                "Frozen, quiet and beautiful. You carry that stillness with you now.");
        chain(E, "Coral Pilgrimage", EXPLORE, "minecraft:warm_ocean", 1, "a Warm Ocean",
                "Where the sea is warm and bright, the coral sings. Journey to a warm ocean and hear it.",
                "The coral's song lives in you now. Few ever hear it.");
        chain(E, "Tide Guardians", KILL, "minecraft:guardian", 8, "Guardians",
                "The monument guardians watch the deep with their single cold eye.|Defeat eight, and prove the water answers to you.",
                "Eight eyes closed. The deep is yours to command.");
        chain(E, "Prismarine Offering", COLLECT, "minecraft:prismarine_shard", 12, "Prismarine Shards",
                "The deep gives up its crystals only to the worthy.|Bring me twelve prismarine shards from the monument.",
                "Shards of the ocean's own heart. You have earned much, reborn one.");
        chain(E, "Wrath of the Deep", KILL, "minecraft:elder_guardian", 1, "an Elder Guardian",
                "At the heart of the ocean monument sleeps the Elder, ancient and cruel.|Defeat it and the sea will call you its child.",
                "The Elder is no more, and the tides bow to you. The ultimate water is yours.");
    }

    // ================================================================== EARTH
    private static void earth() {
        Element E = Element.EARTH;
        chain(E, "Foundation Stones", BUILD, "minecraft:cobblestone", 64, "Cobblestone",
                "Mountains are built one stone at a time.|Place sixty-four cobblestones and build something worthy of the earth.",
                "Solid work. Strong foundations make strong mages.");
        chain(E, "Deep Digger", MINE, "#minecraft:base_stone_overworld", 96, "Stone",
                "The earth speaks softly, and you must dig to hear it.|Mine ninety-six blocks of stone.",
                "You listened well. The stone has begun to answer.");
        chain(E, "Veins of the Mountain", MINE, "#minecraft:gold_ores", 6, "Gold Ore",
                "Gold runs through the mountain like blood through a body.|Find six gold ores and learn the mountain's pulse.",
                "Feel that heartbeat? The mountain lives, and you are part of it.");
        chain(E, "Spider Hollow", KILL, "minecraft:spider,minecraft:cave_spider", 15, "Spiders",
                "The hollows are crawling with spiders that spin their webs across my tunnels.|Clear fifteen of them.",
                "The tunnels are safe again. Thank you, reborn one.");
        chain(E, "Golem's Blessing", BUILD, "minecraft:iron_block", 4, "Iron Blocks",
                "Build a golem and earn the guardianship of stone and iron.|Place four iron blocks and let them walk.",
                "A guardian made of earth and metal. The stone approves.");
        chain(E, "Diamond Heart", MINE, "#minecraft:diamond_ores", 5, "Diamond Ore",
                "Under great pressure, the earth makes its most precious things.|Mine five diamond ores.",
                "Pressure makes diamonds. Pressure makes you.");
        chain(E, "Crawling Terrors", KILL, "minecraft:creeper", 15, "Creepers",
                "Creepers are the earth's rage given form.|Defeat fifteen of them, and try not to lose your house.",
                "You tamed the earth's anger. Now you can wield it.");
        chain(E, "Echoes of the Deep Dark", EXPLORE, "minecraft:deep_dark", 1, "the Deep Dark",
                "Far below, where even stone fears to speak, lies the Deep Dark.|Go there and listen. Quietly.",
                "You returned from the deepest silence. Little can frighten you now.");
        chain(E, "The Silent Giant", KILL, "minecraft:warden", 1, "a Warden",
                "The Warden is the earth's last guardian, blind and deadlier than anything alive.|Defeat it, and you become a mountain yourself.",
                "The giant has fallen. The ultimate earth is yours, reborn one.");
    }

    // =================================================================== WIND
    private static void wind() {
        Element E = Element.WIND;
        chain(E, "Feather Gathering", COLLECT, "minecraft:feather", 12, "Feathers",
                "The wind is light as a feather and just as hard to catch.|Gather twelve feathers and learn to float with it.",
                "Light as air. You are beginning to understand.");
        chain(E, "Sky Walker", EXPLORE, "minecraft:windswept_hills", 1, "Windswept Hills",
                "Where the hills meet the sky, the wind is born. Climb to the windswept hills and breathe it in.",
                "You stood where the wind begins. It knows your name now.");
        chain(E, "Hunt of Phantoms", KILL, "minecraft:phantom", 5, "Phantoms",
                "The sleepless are haunted by phantoms in the night sky. Show them that the wind belongs to you.",
                "The night sky is clearer already.");
        chain(E, "Arrow of the Zephyr", CRAFT, "minecraft:arrow", 32, "Arrows",
                "The wind carries arrows straighter than any archer.|Craft thirty-two and let them fly.",
                "A good quiver. The wind will guide each one.");
        chain(E, "Mountain Peaks", EXPLORE, "minecraft:jagged_peaks", 1, "Jagged Peaks",
                "At the very top of the world the air is thin and wild. Climb the jagged peaks.",
                "From up there you saw the whole world, didn't you?");
        chain(E, "Pillager Raid", KILL, "minecraft:pillager", 12, "Pillagers",
                "Raiders have been stealing my village's grain on the winds of war.|Take twelve of them down.",
                "The raiders are scattered. The wind carries the news of your victory.");
        chain(E, "Wandering Gale", KILL, "minecraft:vindicator,minecraft:evoker", 8, "Vindicators or Evokers",
                "There are fiercer raiders in the woodland mansions, and they do not run.|Defeat eight of them.",
                "Faster than their axes, lighter than their spells. You are the gale.");
        chain(E, "Cloud Offering", COLLECT, "minecraft:phantom_membrane", 10, "Phantom Membranes",
                "The clouds accept only gifts of the sky. Phantom membranes will do.|Bring me ten.",
                "The clouds themselves bow to you.");
        chain(E, "Master of the Skies", KILL, "minecraft:ravager", 2, "Ravagers",
                "Ravagers are the thunder on the ground, beasts the wind cannot move.|Defeat two and you will master the sky itself.",
                "Beasts of the ground, felled by the wind. The ultimate wind is yours.");
    }

    // ================================================================== LIGHT
    private static void light() {
        Element E = Element.LIGHT;
        chain(E, "Offering of Bread", COLLECT, "minecraft:bread", 10, "Bread",
                "Light begins in kindness. Bring me ten loaves of bread for the hungry in the village.",
                "The children are fed, and your heart is lighter. That is where the light begins.");
        chain(E, "Purge the Undead", KILL,
                "minecraft:zombie,minecraft:skeleton,minecraft:drowned,minecraft:husk,minecraft:stray", 25, "Undead",
                "The undead hate the light most of all. Purge twenty-five of them from the land.",
                "The dark recoils from you. Good.");
        chain(E, "Golden Hymn", COLLECT, "minecraft:gold_ingot", 12, "Gold Ingots",
                "Gold carries light's song best. Bring me twelve ingots for the village shrine.",
                "Its hymn rings clearly. The shrine shines again.");
        chain(E, "Healer's Garden", BUILD, "#minecraft:flowers", 20, "Flowers",
                "Plant a garden for the weary, twenty flowers in full bloom.",
                "What a garden! Life blooms wherever you walk.");
        chain(E, "Healer's Hand", CRAFT, "minecraft:golden_apple", 1, "a Golden Apple",
                "A true healer must be able to craft the rarest medicine. Make a golden apple.",
                "Rare and precious, like the one who made it.");
        chain(E, "Vigil of the Village", KILL, "minecraft:zombie_villager", 6, "Zombie Villagers",
                "Some villagers have fallen to the curse. Release six of them, so they may rest in peace.",
                "They are free of the curse. Your light touched them, even then.");
        chain(E, "Temple of Light", EXPLORE, "minecraft:cherry_grove", 1, "a Cherry Grove",
                "In the cherry groves, it is said, the first light fell to earth. Go there and pray.",
                "Petals and light. You walk a gentle path.");
        chain(E, "Lanterns of Hope", BUILD, "minecraft:torch,minecraft:wall_torch", 60, "Torches",
                "Light a hundred paths. Well, sixty will do for now. Place sixty torches against the dark.",
                "The land is bright with your torches. The dark has fewer places to hide.");
        chain(E, "Dawn Breaker", KILL, "minecraft:ender_dragon", 1, "the Ender Dragon",
                "At the edge of the world waits the oldest dragon of all. Defeat it, and the dawn itself will answer to you.",
                "A new dawn breaks, and you are its herald. The ultimate light is yours.");
    }

    // ============================================================== LIGHTNING
    private static void lightning() {
        Element E = Element.LIGHTNING;
        chain(E, "Static Charge", COLLECT, "minecraft:copper_ingot", 16, "Copper Ingots",
                "Lightning loves copper. Bring me sixteen ingots and I will teach you to hold a charge.",
                "Feel the tingle? That is the sky saying hello.");
        chain(E, "Lightning Rod", CRAFT, "minecraft:lightning_rod", 1, "a Lightning Rod",
                "Before you call the storm, learn to catch it. Craft a lightning rod.",
                "A rod to catch the sky. Good.");
        chain(E, "Storm Chaser", EXPLORE, "minecraft:savanna", 1, "a Savanna",
                "Storms gather over the wide plains of the savanna. Go there and chase the thunder.",
                "You chased the storm and came back unscathed. Remarkable.");
        chain(E, "Charged Hunt", KILL, "minecraft:creeper", 10, "Creepers",
                "Creepers carry the sky's wrath inside them. Show them whose lightning is fiercer.",
                "A fiercer spark than theirs. You are the storm now.");
        chain(E, "Thunder Forge", MINE, "#minecraft:copper_ores", 24, "Copper Ore",
                "Mine twenty-four copper ores. Every storm needs a forge.",
                "The forge burns with blue lightning. Beautiful.");
        chain(E, "Wired Mind", CRAFT, "minecraft:comparator", 1, "a Redstone Comparator",
                "A lightning mage must think as quickly as the bolt. Craft a redstone comparator.",
                "Quick hands, quick mind. The storm rewards you.");
        chain(E, "Witch's Brew", KILL, "minecraft:witch", 8, "Witches",
                "The swamp witches brew storms in cauldrons. Eight of them must be stopped.",
                "The brew is spilled, the storm is tamed.");
        chain(E, "Storm Peak", BUILD, "minecraft:lightning_rod", 4, "Lightning Rods",
                "Place four lightning rods high above the earth. Let the sky strike them.",
                "Four rods, four blessings. The sky sees you.");
        chain(E, "Thunder God's Trial", KILL, "minecraft:evoker", 6, "Evokers",
                "The Thunder God tests those who would wield his wrath. Six evokers must fall.",
                "The trial is passed. The ultimate lightning is yours.");
    }

    // =================================================================== DARK
    private static void dark() {
        Element E = Element.DARK;
        chain(E, "Into the Night", COLLECT, "minecraft:spider_eye", 8, "Spider Eyes",
                "Dark magic needs eyes that see in the dark. Bring me eight spider eyes.",
                "Their eyes see for you now. The night is no longer a stranger.");
        chain(E, "Bone Collector", COLLECT, "minecraft:bone", 20, "Bones",
                "Dark magic is built on bones. Bring me twenty of them.",
                "A tidy pile of bones. They whisper your name.");
        chain(E, "Endermen Stare", KILL, "minecraft:enderman", 8, "Endermen",
                "The Endermen guard the void's secrets. Do not meet their gaze. Defeat eight of them.",
                "You faced the void's own eyes. It looks back at you with respect.");
        chain(E, "Cursed Brew", CRAFT, "minecraft:fermented_spider_eye", 1, "a Fermented Spider Eye",
                "Every curse starts as a brew. Craft a fermented spider eye.",
                "Foul. Poisonous. Perfect.");
        chain(E, "Ruins of Shadow", EXPLORE, "minecraft:dark_forest", 1, "a Dark Forest",
                "In the dark forest, the sun forgets to shine. Go there and learn from the shadows.",
                "You walked in the shadows and the shadows walked with you.");
        chain(E, "Nightmare Hunters", KILL, "minecraft:witch,minecraft:phantom", 12, "Witches or Phantoms",
                "Not all nightmares belong to the dark. Hunt twelve witches or phantoms.",
                "The nightmares are yours now, to command rather than fear.");
        chain(E, "Soul Harvest", KILL, "minecraft:wither_skeleton", 8, "Wither Skeletons",
                "In the Nether fortresses, souls linger in bone. Harvest eight of them.",
                "Eight souls added to your power. They will serve you well.");
        chain(E, "Void Offering", COLLECT, "minecraft:ender_pearl", 12, "Ender Pearls",
                "The void accepts offerings of its own kind. Bring me twelve ender pearls.",
                "The void is satisfied. It opens for you.");
        chain(E, "Eclipse", KILL, "minecraft:wither", 1, "the Wither",
                "To rule the dark, you must defeat the darkest thing of all: the Wither.|Destroy it, and the sun itself will hide in shame.",
                "The sun hides and the moon bows. The ultimate dark is yours, reborn one.");
    }
}
