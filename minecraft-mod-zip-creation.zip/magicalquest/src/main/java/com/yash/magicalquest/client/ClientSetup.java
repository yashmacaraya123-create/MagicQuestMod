package com.yash.magicalquest.client;

import com.yash.magicalquest.MagicalQuest;
import com.yash.magicalquest.client.model.MageModel;
import com.yash.magicalquest.client.render.MageRenderer;
import com.yash.magicalquest.registry.ModEntities;
import net.minecraft.client.renderer.entity.NoopRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Client-only mod-bus registration. */
@Mod.EventBusSubscriber(modid = MagicalQuest.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    private ClientSetup() {
    }

    @SubscribeEvent
    public static void keys(RegisterKeyMappingsEvent event) {
        event.register(ClientKeys.WHEEL);
        event.register(ClientKeys.CAST);
        event.register(ClientKeys.STATUS);
    }

    @SubscribeEvent
    public static void overlays(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("magic_hud", new ManaHud());
    }

    @SubscribeEvent
    public static void layers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(MageModel.LAYER, MageModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.MAGE.get(), MageRenderer::new);
        event.registerEntityRenderer(ModEntities.MAGIC_PROJECTILE.get(), NoopRenderer::new);
    }
}
