package com.yash.magicalquest.client;

import com.yash.magicalquest.magic.PlayerMagic;
import com.yash.magicalquest.quest.Quest;
import com.yash.magicalquest.quest.QuestManager;
import com.yash.magicalquest.skill.Skill;
import com.yash.magicalquest.skill.Skills;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

/** Mana bar, selected skill and quest tracker. */
public class ManaHud implements IGuiOverlay {
    @Override
    public void render(ForgeGui gui, GuiGraphics g, float partialTick, int width, int height) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.options.hideGui) {
            return;
        }
        PlayerMagic m = PlayerMagic.get(player);
        if (!m.chosen) {
            return;
        }
        Font font = mc.font;
        int col = m.element.argb();

        // ---- skill icon + mana bar, left of the hotbar
        int x = Math.max(4, width / 2 - 250);
        int y = height - 26;
        Skill skill = Skills.get(m.selected);
        g.fill(x - 1, y - 1, x + 21, y + 21, col);
        g.fill(x, y, x + 20, y + 20, 0xEE10091C);
        if (skill != null && skill.element == m.element) {
            g.blit(skill.iconTexture(), x + 2, y + 2, 16, 16, 0f, 0f, 16, 16, 16, 16);
            int cd = m.cooldown(skill.id);
            if (cd > 0) {
                int h = Math.round(20f * Math.min(1f, cd / (float) skill.cooldown));
                g.fill(x, y, x + 20, y + h, 0xAA000000);
                String secs = String.valueOf((int) Math.ceil(cd / 20f));
                g.drawString(font, secs, x + 10 - font.width(secs) / 2, y + 6, 0xFFFFFFFF, true);
            } else if (m.mana < skill.manaCost) {
                g.fill(x, y, x + 20, y + 20, 0x66FF0000);
            }
        }
        float max = m.maxMana();
        int bw = 100;
        int bx = x + 24;
        int by = y + 11;
        g.fill(bx - 1, by - 1, bx + bw + 1, by + 9, 0xFF000000);
        g.fill(bx, by, bx + bw, by + 8, 0xFF1A1230);
        int fill = Math.round(bw * Math.min(1f, m.mana / max));
        g.fill(bx, by, bx + fill, by + 8, col);
        g.fill(bx, by, bx + fill, by + 3, 0x55FFFFFF);
        String manaText = (int) m.mana + "/" + (int) max;
        g.drawString(font, manaText, bx + bw / 2 - font.width(manaText) / 2, by, 0xFFFFFFFF, true);
        String name = skill != null && skill.element == m.element ? skill.name : "No skill - hold [R]";
        g.drawString(font, name, bx, y - 1, col, true);

        // ---- quest tracker, top-left
        Quest q = QuestManager.active(m);
        if (q != null && mc.screen == null && !mc.options.renderDebug) {
            int prog = QuestManager.progress(player, m, q);
            boolean done = prog >= q.count;
            g.drawString(font, "Quest: " + q.title, 6, 6, 0xFFFFD25A, true);
            g.drawString(font, q.objective(prog), 6, 17, done ? 0xFF7CFF8A : 0xFFE6E6E6, true);
            if (done) {
                g.drawString(font, "Return to a Village Mage", 6, 28, 0xFF7CFF8A, true);
            }
        }
    }
}
