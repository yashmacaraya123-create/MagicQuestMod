package com.yash.magicalquest.quest;

public enum QuestType {
    KILL("Defeat"),
    MINE("Mine"),
    COLLECT("Gather"),
    BUILD("Place"),
    CRAFT("Craft"),
    EXPLORE("Discover");

    public final String verb;

    QuestType(String verb) {
        this.verb = verb;
    }
}
