package com.yash.magicalquest.entity;

import com.yash.magicalquest.element.Element;
import com.yash.magicalquest.skill.Fx;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

import java.util.function.Consumer;

/** A glowing ball of elemental energy. Visuals are pure particles, so it is very light. */
public class MagicProjectile extends ThrowableProjectile {
    private static final EntityDataAccessor<Integer> ELEMENT =
            SynchedEntityData.defineId(MagicProjectile.class, EntityDataSerializers.INT);

    private float damage = 5f;
    private float aoe = 0f;
    private float gravity = 0f;
    private Consumer<LivingEntity> onHitEffect;

    public MagicProjectile(EntityType<? extends MagicProjectile> type, Level level) {
        super(type, level);
    }

    public void configure(Element element, float damage, float aoe, float gravity, Consumer<LivingEntity> effect) {
        this.entityData.set(ELEMENT, element.ordinal());
        this.damage = damage;
        this.aoe = aoe;
        this.gravity = gravity;
        this.onHitEffect = effect;
    }

    public Element element() {
        return Element.byOrdinal(this.entityData.get(ELEMENT));
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(ELEMENT, 0);
    }

    @Override
    protected float getGravity() {
        return gravity;
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            Element el = element();
            for (int i = 0; i < 2; i++) {
                level().addParticle(new DustParticleOptions(el.rgb(), 1.4f),
                        getX() + (random.nextDouble() - 0.5) * 0.2, getY() + (random.nextDouble() - 0.5) * 0.2,
                        getZ() + (random.nextDouble() - 0.5) * 0.2, 0, 0, 0);
            }
            level().addParticle(Fx.accentOf(el), getX(), getY(), getZ(), 0, 0, 0);
        } else if (tickCount > 80) {
            discard();
        }
    }

    @Override
    protected void onHit(HitResult result) {
        if (level().isClientSide) {
            return;
        }
        Vec3 pos = result.getLocation();
        Entity owner = getOwner();
        if (owner instanceof ServerPlayer sp && level() instanceof ServerLevel sl) {
            Element el = element();
            if (aoe > 0) {
                Fx.area(sp, el, pos, aoe, damage, 0.3, onHitEffect);
                sl.sendParticles(net.minecraft.core.particles.ParticleTypes.EXPLOSION, pos.x, pos.y, pos.z, 1, 0, 0, 0, 0);
            } else {
                if (result instanceof EntityHitResult ehr && Fx.valid(sp, ehr.getEntity())) {
                    LivingEntity target = (LivingEntity) ehr.getEntity();
                    Fx.hurt(sp, target, damage);
                    if (onHitEffect != null) {
                        onHitEffect.accept(target);
                    }
                }
                Fx.dust(sl, el, pos.x, pos.y, pos.z, 18, 0.25, 1.3f);
                Fx.accent(sl, el, pos.x, pos.y, pos.z, 8, 0.2, 0.08);
                Fx.impactSound(sl, el, pos, 0.4f);
            }
        }
        discard();
    }

    @Override
    public boolean shouldBeSaved() {
        return false;
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
