package com.yash.magicalquest.skill;

import com.yash.magicalquest.element.Element;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Registry of every skill in the mod (10 per element). */
public final class Skills {
    private static final Map<String, Skill> ALL = new LinkedHashMap<>();
    private static final Map<Element, List<Skill>> BY_ELEMENT = new EnumMap<>(Element.class);

    static {
        for (Element e : Element.values()) {
            BY_ELEMENT.put(e, new ArrayList<>());
        }
        SkillDefs.registerAll();
    }

    private Skills() {
    }

    static Skill def(Element element, String name, String description, int mana, int cooldown,
                     Skill.Icon icon, Skill.Caster caster) {
        List<Skill> list = BY_ELEMENT.get(element);
        String id = element.id() + "_" + name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "_").replaceAll("^_|_$", "");
        Skill skill = new Skill(id, element, list.size(), name, description, mana, cooldown, icon, caster);
        list.add(skill);
        ALL.put(id, skill);
        return skill;
    }

    public static Skill get(String id) {
        return id == null ? null : ALL.get(id);
    }

    public static List<Skill> of(Element element) {
        return Collections.unmodifiableList(BY_ELEMENT.get(element));
    }

    public static Collection<Skill> all() {
        return Collections.unmodifiableCollection(ALL.values());
    }
}
