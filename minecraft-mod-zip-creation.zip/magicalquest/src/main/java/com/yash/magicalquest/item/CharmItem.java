package com.yash.magicalquest.item;

import com.yash.magicalquest.element.Element;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

/** Carry it in your inventory: +50% mana regeneration and a stronger passive for mages of the same element. */
public class CharmItem extends Item {
    public final Element element;

    public CharmItem(Element element, Properties properties) {
        super(properties);
        this.element = element;
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal(element.displayName + " mages only").withStyle(Style.EMPTY.withColor(element.color)));
        tooltip.add(Component.literal("Carry in your inventory:").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("+50% mana regeneration").withStyle(ChatFormatting.AQUA));
        tooltip.add(Component.literal("Stronger elemental passive").withStyle(ChatFormatting.AQUA));
    }
}
