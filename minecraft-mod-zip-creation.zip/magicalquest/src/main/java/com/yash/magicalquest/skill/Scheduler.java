package com.yash.magicalquest.skill;

import com.yash.magicalquest.MagicalQuest;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Tiny server-side delayed task runner used by multi-hit skills. Server thread only. */
public final class Scheduler {
    private static final List<Task> TASKS = new ArrayList<>();

    private static final class Task {
        int ticks;
        final Runnable action;

        Task(int ticks, Runnable action) {
            this.ticks = ticks;
            this.action = action;
        }
    }

    private Scheduler() {
    }

    public static void later(int ticks, Runnable action) {
        TASKS.add(new Task(Math.max(1, ticks), action));
    }

    public static void tick() {
        if (TASKS.isEmpty()) {
            return;
        }
        List<Runnable> due = new ArrayList<>();
        Iterator<Task> it = TASKS.iterator();
        while (it.hasNext()) {
            Task t = it.next();
            if (--t.ticks <= 0) {
                due.add(t.action);
                it.remove();
            }
        }
        for (Runnable r : due) {
            try {
                r.run();
            } catch (Exception e) {
                MagicalQuest.LOGGER.error("Scheduled skill task failed", e);
            }
        }
    }

    public static void clear() {
        TASKS.clear();
    }
}
