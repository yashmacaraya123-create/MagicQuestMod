package com.yash.magicalquest.client.screen;

import com.mojang.blaze3d.platform.InputConstants;
import com.yash.magicalquest.client.ClientKeys;
import com.yash.magicalquest.client.ClientText;
import com.yash.magicalquest.element.Element;
import com.yash.magicalquest.magic.PlayerMagic;
import com.yash.magicalquest.network.Net;
import com.yash.magicalquest.network.SelectSkillPacket;
import com.yash.magicalquest.skill.Skill;
import com.yash.magicalquest.skill.Skills;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/** Hold the wheel key, move the mouse toward a skill, release to select it. */
public class SkillWheelScreen extends Screen {
    private List<Skill> skills = List.of();
    private int hover = -1;
    private Element element = Element.FIRE;
    private PlayerMagic magic;

    public SkillWheelScreen() {
        super(Component.literal("Skills"));
    }

    @Override
    protected void init() {
        Minecraft mc = Minecraft.getInstance();
        magic = PlayerMagic.get(mc.player);
        element = magic.element;
        skills = Skills.of(element).stream().filter(s -> magic.unlocked.contains(s.id)).toList();
        hover = -1;
        for (int i = 0; i < skills.size(); i++) {
            if (skills.get(i).id.equals(magic.selected)) {
                hover = i;
            }
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private boolean wheelKeyDown() {
        Minecraft mc = Minecraft.getInstance();
        long window = mc.getWindow().getWindow();
        InputConstants.Key key = ClientKeys.WHEEL.getKey();
        if (key.getType() == InputConstants.Type.MOUSE) {
            return GLFW.glfwGetMouseButton(window, key.getValue()) == GLFW.GLFW_PRESS;
        }
        return InputConstants.isKeyDown(window, key.getValue());
    }

    @Override
    public void tick() {
        if (!wheelKeyDown()) {
            confirmAndClose();
        }
    }

    private void confirmAndClose() {
        if (hover >= 0 && hover < skills.size()) {
            Skill s = skills.get(hover);
            if (!s.id.equals(magic.selected)) {
                magic.selected = s.id;
                Net.toServer(new SelectSkillPacket(s.id));
            }
        }
        onClose();
    }

    private double angleOf(int i, int n) {
        return -Math.PI / 2 + 2 * Math.PI * i / n;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        g.fillGradient(0, 0, width, height, 0x66000000, 0xAA000000);
        int n = skills.size();
        int cx = width / 2;
        int cy = height / 2 - 14;
        int radius = Math.max(48, Math.min(82, height / 2 - 70));
        int col = element.argb();

        // decorative ring
        for (int d = 0; d < 360; d += 4) {
            double a = Math.toRadians(d);
            int rx = cx + (int) (Math.cos(a) * (radius + 26));
            int ry = cy + (int) (Math.sin(a) * (radius + 26));
            g.fill(rx, ry, rx + 2, ry + 2, 0x44000000 | element.color);
        }

        if (n == 0) {
            g.drawCenteredString(font, "No skills unlocked yet", cx, cy, 0xFFFFFFFF);
            return;
        }

        // hover from mouse direction
        double dx = mx - cx;
        double dy = my - cy;
        if (Math.hypot(dx, dy) > 22) {
            double ang = Math.atan2(dy, dx);
            double best = Double.MAX_VALUE;
            for (int i = 0; i < n; i++) {
                double a = angleOf(i, n);
                double diff = Math.abs(Math.atan2(Math.sin(ang - a), Math.cos(ang - a)));
                if (diff < best) {
                    best = diff;
                    hover = i;
                }
            }
        }

        for (int i = 0; i < n; i++) {
            Skill s = skills.get(i);
            double a = angleOf(i, n);
            int sx = cx + (int) Math.round(Math.cos(a) * radius) - 19;
            int sy = cy + (int) Math.round(Math.sin(a) * radius) - 19;
            boolean h = i == hover;
            boolean current = s.id.equals(magic.selected);
            if (h) {
                g.fill(sx - 3, sy - 3, sx + 41, sy + 41, 0x66000000 | element.color);
            }
            g.fill(sx - 1, sy - 1, sx + 39, sy + 39, h ? 0xFFFFFFFF : current ? 0xFFFFD25A : 0xFF3A3050);
            g.fill(sx, sy, sx + 38, sy + 38, 0xFF10091C);
            g.blit(s.iconTexture(), sx + 3, sy + 3, 32, 32, 0f, 0f, 16, 16, 16, 16);
            int cd = magic.cooldown(s.id);
            if (cd > 0) {
                int hh = Math.round(38f * Math.min(1f, cd / (float) s.cooldown));
                g.fill(sx, sy, sx + 38, sy + hh, 0xAA000000);
            } else if (magic.mana < s.manaCost) {
                g.fill(sx, sy, sx + 38, sy + 38, 0x55FF0000);
            }
            g.drawString(font, String.valueOf(i + 1), sx + 2, sy + 2, 0xFFCCCCCC, true);
        }

        // centre label + info of hovered skill
        g.drawCenteredString(font, element.displayName, cx, cy - 8, col);
        g.drawCenteredString(font, (int) magic.mana + " mana", cx, cy + 4, 0xFFBDE9FF);
        if (hover >= 0 && hover < n) {
            Skill s = skills.get(hover);
            int iy = cy + radius + 34;
            g.drawCenteredString(font, s.name, cx, iy, col);
            List<String> desc = ClientText.wrap(font, s.description, 260);
            int y = iy + 12;
            for (String line : desc) {
                g.drawCenteredString(font, line, cx, y, 0xFFE2DAF5);
                y += 10;
            }
            g.drawCenteredString(font, "Mana " + s.manaCost + "  |  Cooldown " + String.format("%.1f", s.cooldown / 20f) + "s",
                    cx, y + 2, 0xFF9FB8FF);
        }
    }
}
