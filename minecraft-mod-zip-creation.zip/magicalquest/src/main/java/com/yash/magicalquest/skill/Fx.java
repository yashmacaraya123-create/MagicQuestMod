package com.yash.magicalquest.skill;

import com.yash.magicalquest.element.Element;
import com.yash.magicalquest.entity.MageEntity;
import com.yash.magicalquest.entity.MagicProjectile;
import com.yash.magicalquest.magic.PlayerMagic;
import com.yash.magicalquest.registry.ModEntities;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.IntConsumer;

/** Reusable building blocks for skills: projectiles, beams, bursts, dashes, teleports, particles. */
public final class Fx {
    private Fx() {
    }

    public record Aim(Vec3 pos, LivingEntity entity, boolean hit) {
    }

    private static final Map<Element, ParticleOptions> ACCENT = new EnumMap<>(Element.class);
    private static final Map<Element, SoundEvent> CAST_SOUND = new EnumMap<>(Element.class);
    private static final Map<Element, SoundEvent> IMPACT_SOUND = new EnumMap<>(Element.class);

    static {
        ACCENT.put(Element.FIRE, ParticleTypes.FLAME);
        ACCENT.put(Element.WATER, ParticleTypes.SPLASH);
        ACCENT.put(Element.EARTH, ParticleTypes.POOF);
        ACCENT.put(Element.WIND, ParticleTypes.CLOUD);
        ACCENT.put(Element.LIGHT, ParticleTypes.END_ROD);
        ACCENT.put(Element.LIGHTNING, ParticleTypes.ELECTRIC_SPARK);
        ACCENT.put(Element.DARK, ParticleTypes.PORTAL);

        CAST_SOUND.put(Element.FIRE, SoundEvents.BLAZE_SHOOT);
        CAST_SOUND.put(Element.WATER, SoundEvents.PLAYER_SPLASH);
        CAST_SOUND.put(Element.EARTH, SoundEvents.STONE_BREAK);
        CAST_SOUND.put(Element.WIND, SoundEvents.PHANTOM_FLAP);
        CAST_SOUND.put(Element.LIGHT, SoundEvents.AMETHYST_BLOCK_CHIME);
        CAST_SOUND.put(Element.LIGHTNING, SoundEvents.LIGHTNING_BOLT_IMPACT);
        CAST_SOUND.put(Element.DARK, SoundEvents.WITHER_SHOOT);

        IMPACT_SOUND.put(Element.FIRE, SoundEvents.GENERIC_EXPLODE);
        IMPACT_SOUND.put(Element.WATER, SoundEvents.GENERIC_SPLASH);
        IMPACT_SOUND.put(Element.EARTH, SoundEvents.DEEPSLATE_BREAK);
        IMPACT_SOUND.put(Element.WIND, SoundEvents.PHANTOM_SWOOP);
        IMPACT_SOUND.put(Element.LIGHT, SoundEvents.AMETHYST_CLUSTER_BREAK);
        IMPACT_SOUND.put(Element.LIGHTNING, SoundEvents.LIGHTNING_BOLT_THUNDER);
        IMPACT_SOUND.put(Element.DARK, SoundEvents.ENDERMAN_TELEPORT);
    }

    // ------------------------------------------------------------------ basics

    public static ParticleOptions accentOf(Element el) {
        return ACCENT.get(el);
    }

    /** Damage scales slowly as the player completes quests. */
    public static float power(ServerPlayer p) {
        return 1f + Math.min(1.0f, PlayerMagic.get(p).completedQuests.size() * 0.02f);
    }

    public static boolean valid(Entity source, Entity target) {
        if (!(target instanceof LivingEntity le) || !le.isAlive() || target == source) {
            return false;
        }
        if (target instanceof Player || target instanceof AbstractVillager || target instanceof MageEntity
                || target instanceof ArmorStand) {
            return false;
        }
        if (target instanceof TamableAnimal ta && ta.isTame()) {
            return false;
        }
        return !(target instanceof IronGolem golem && golem.isPlayerCreated());
    }

    public static void castSound(ServerPlayer p, Element el) {
        p.level().playSound(null, p.getX(), p.getY(), p.getZ(), CAST_SOUND.get(el), SoundSource.PLAYERS, 0.8f, 1.0f);
    }

    public static void impactSound(ServerLevel l, Element el, Vec3 pos, float volume) {
        l.playSound(null, pos.x, pos.y, pos.z, IMPACT_SOUND.get(el), SoundSource.PLAYERS, volume, 1.0f);
    }

    public static void hurt(ServerPlayer p, LivingEntity target, float dmg) {
        target.hurt(p.damageSources().indirectMagic(p, p), dmg * power(p));
    }

    public static void eff(LivingEntity e, MobEffect effect, int seconds, int amplifier) {
        e.addEffect(new MobEffectInstance(effect, seconds * 20, amplifier));
    }

    // --------------------------------------------------------------- particles

    public static void dust(ServerLevel l, Element el, double x, double y, double z, int n, double spread, float size) {
        l.sendParticles(new DustParticleOptions(el.rgb(), size), x, y, z, n, spread, spread, spread, 0.0);
    }

    public static void accent(ServerLevel l, Element el, double x, double y, double z, int n, double spread, double speed) {
        l.sendParticles(ACCENT.get(el), x, y, z, n, spread, spread, spread, speed);
    }

    public static void ring(ServerLevel l, Element el, Vec3 c, double r) {
        int n = (int) Math.max(16, r * 8);
        for (int i = 0; i < n; i++) {
            double a = i * 2 * Math.PI / n;
            double x = c.x + Math.cos(a) * r;
            double z = c.z + Math.sin(a) * r;
            dust(l, el, x, c.y + 0.2, z, 1, 0.05, 1.3f);
            if (i % 3 == 0) {
                accent(l, el, x, c.y + 0.3, z, 1, 0.1, 0.02);
            }
        }
    }

    public static void column(ServerLevel l, Element el, Vec3 c, double height) {
        for (double y = 0; y < height; y += 0.5) {
            dust(l, el, c.x, c.y + y, c.z, 2, 0.25, 1.4f);
            if (((int) (y * 2)) % 2 == 0) {
                accent(l, el, c.x, c.y + y, c.z, 1, 0.3, 0.05);
            }
        }
    }

    public static void aura(ServerPlayer p, Element el) {
        ServerLevel l = p.serverLevel();
        for (int i = 0; i < 24; i++) {
            double a = i * Math.PI / 6;
            double y = p.getY() + 0.1 + (i / 24.0) * 1.9;
            dust(l, el, p.getX() + Math.cos(a) * 0.9, y, p.getZ() + Math.sin(a) * 0.9, 1, 0.05, 1.2f);
        }
        accent(l, el, p.getX(), p.getY() + 1, p.getZ(), 12, 0.6, 0.05);
    }

    public static void line(ServerLevel l, Element el, Vec3 a, Vec3 b) {
        double len = a.distanceTo(b);
        if (len < 0.1) {
            return;
        }
        Vec3 step = b.subtract(a).normalize().scale(0.5);
        Vec3 cur = a;
        int steps = (int) (len * 2);
        for (int i = 0; i < steps; i++) {
            dust(l, el, cur.x, cur.y, cur.z, 1, 0.04, 1.1f);
            if (i % 2 == 0) {
                accent(l, el, cur.x, cur.y, cur.z, 1, 0.05, 0.01);
            }
            cur = cur.add(step);
        }
    }

    // ------------------------------------------------------------- targeting

    public static List<LivingEntity> around(ServerPlayer p, Vec3 c, double r) {
        AABB box = new AABB(c.x - r, c.y - r, c.z - r, c.x + r, c.y + r, c.z + r);
        double lim = (r + 0.4) * (r + 0.4);
        return p.serverLevel().getEntitiesOfClass(LivingEntity.class, box,
                e -> valid(p, e) && e.getBoundingBox().getCenter().distanceToSqr(c) <= lim);
    }

    public static Aim aim(ServerPlayer p, double range) {
        ServerLevel l = p.serverLevel();
        Vec3 start = p.getEyePosition();
        Vec3 end = start.add(p.getLookAngle().scale(range));
        BlockHitResult bh = l.clip(new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        boolean hit = bh.getType() != HitResult.Type.MISS;
        Vec3 point = hit ? bh.getLocation() : end;
        LivingEntity best = null;
        double bestDist = start.distanceToSqr(point);
        for (LivingEntity e : l.getEntitiesOfClass(LivingEntity.class, new AABB(start, point).inflate(1.5), x -> valid(p, x))) {
            Optional<Vec3> h = e.getBoundingBox().inflate(0.35).clip(start, point);
            if (h.isPresent()) {
                double d = start.distanceToSqr(h.get());
                if (d < bestDist) {
                    bestDist = d;
                    best = e;
                }
            }
        }
        if (best != null) {
            return new Aim(best.position(), best, true);
        }
        return new Aim(point, null, hit);
    }

    // ------------------------------------------------------------- delivery

    public static void pulses(ServerPlayer p, int count, int interval, IntConsumer action) {
        for (int i = 0; i < count; i++) {
            final int index = i;
            Scheduler.later(1 + i * interval, () -> {
                if (p.isAlive() && !p.isRemoved()) {
                    action.accept(index);
                }
            });
        }
    }

    public static void projectile(ServerPlayer p, Element el, float speed, float dmg, float aoe, float gravity,
                                  Consumer<LivingEntity> fx) {
        ServerLevel l = p.serverLevel();
        MagicProjectile pr = new MagicProjectile(ModEntities.MAGIC_PROJECTILE.get(), l);
        pr.setOwner(p);
        pr.configure(el, dmg, aoe, gravity, fx);
        Vec3 look = p.getLookAngle();
        Vec3 pos = p.getEyePosition().add(look.scale(0.8)).add(0, -0.2, 0);
        pr.setPos(pos.x, pos.y, pos.z);
        pr.shoot(look.x, look.y, look.z, speed, 0.0f);
        l.addFreshEntity(pr);
    }

    /** Instant beam. Hits up to maxHits entities along the line. */
    public static List<LivingEntity> bolt(ServerPlayer p, Element el, double range, float dmg, int maxHits,
                                          Consumer<LivingEntity> fx) {
        ServerLevel l = p.serverLevel();
        Vec3 start = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        Vec3 end = start.add(look.scale(range));
        BlockHitResult bh = l.clip(new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        if (bh.getType() != HitResult.Type.MISS) {
            end = bh.getLocation();
        }
        final Vec3 fend = end;
        record Hit(double dist, LivingEntity entity) {
        }
        List<Hit> hits = new ArrayList<>();
        for (LivingEntity e : l.getEntitiesOfClass(LivingEntity.class, new AABB(start, fend).inflate(1.5), x -> valid(p, x))) {
            Optional<Vec3> h = e.getBoundingBox().inflate(0.4).clip(start, fend);
            if (h.isPresent()) {
                hits.add(new Hit(start.distanceToSqr(h.get()), e));
            }
        }
        hits.sort(Comparator.comparingDouble(Hit::dist));
        List<LivingEntity> result = new ArrayList<>();
        Vec3 visualEnd = fend;
        for (Hit h : hits) {
            if (result.size() >= maxHits) {
                break;
            }
            result.add(h.entity());
            visualEnd = h.entity().getBoundingBox().getCenter();
        }
        line(l, el, start.add(0, -0.25, 0).add(look.scale(0.7)), maxHits >= 6 ? fend : visualEnd);
        for (LivingEntity e : result) {
            if (dmg > 0) {
                hurt(p, e, dmg);
            }
            if (fx != null) {
                fx.accept(e);
            }
        }
        return result;
    }

    public static void knock(Vec3 from, LivingEntity e, double strength, double lift) {
        Vec3 d = e.position().subtract(from);
        d = new Vec3(d.x, 0, d.z);
        d = d.lengthSqr() < 1.0E-4 ? new Vec3(0.3, 0, 0.3) : d.normalize();
        e.setDeltaMovement(e.getDeltaMovement().add(d.x * strength, lift, d.z * strength));
        e.hurtMarked = true;
    }

    public static void launch(LivingEntity e, double y) {
        Vec3 m = e.getDeltaMovement();
        e.setDeltaMovement(m.x, y, m.z);
        e.hurtMarked = true;
    }

    public static void pull(ServerPlayer p, Vec3 center, double radius, double strength) {
        for (LivingEntity e : around(p, center, radius)) {
            Vec3 dir = center.subtract(e.getBoundingBox().getCenter());
            if (dir.length() > 0.6) {
                e.setDeltaMovement(e.getDeltaMovement().scale(0.6).add(dir.normalize().scale(strength)));
                e.fallDistance = 0;
                e.hurtMarked = true;
            }
        }
    }

    /** Area damage around a point with a visual ring. */
    public static List<LivingEntity> area(ServerPlayer p, Element el, Vec3 c, double r, float dmg, double lift,
                                          Consumer<LivingEntity> fx) {
        ServerLevel l = p.serverLevel();
        List<LivingEntity> hit = around(p, c, r);
        for (LivingEntity e : hit) {
            if (dmg > 0) {
                hurt(p, e, dmg);
            }
            if (lift > 0) {
                launch(e, lift);
            }
            if (fx != null) {
                fx.accept(e);
            }
        }
        ring(l, el, c, r);
        accent(l, el, c.x, c.y + 0.5, c.z, (int) (10 + r * 4), r * 0.4, 0.08);
        impactSound(l, el, c, 0.6f);
        return hit;
    }

    /** Burst centred on the caster. */
    public static List<LivingEntity> burst(ServerPlayer p, Element el, double r, float dmg, float knock,
                                           Consumer<LivingEntity> fx) {
        ServerLevel l = p.serverLevel();
        Vec3 c = p.position().add(0, 0.8, 0);
        List<LivingEntity> hit = around(p, c, r);
        for (LivingEntity e : hit) {
            if (dmg > 0) {
                hurt(p, e, dmg);
            }
            if (knock > 0) {
                knock(p.position(), e, knock, 0.35);
            }
            if (fx != null) {
                fx.accept(e);
            }
        }
        for (double rr = 1; rr <= r; rr += Math.max(1.0, r / 4)) {
            ring(l, el, p.position(), rr);
        }
        accent(l, el, c.x, c.y, c.z, (int) (20 + r * 6), r * 0.35, 0.12);
        impactSound(l, el, c, 0.8f);
        return hit;
    }

    public static void dash(ServerPlayer p, Element el, double power, float dmg, Consumer<LivingEntity> fx) {
        Vec3 look = p.getLookAngle();
        p.setDeltaMovement(look.x * power, Math.max(0.12, look.y * power * 0.6), look.z * power);
        p.hurtMarked = true;
        p.fallDistance = 0;
        Set<UUID> done = new HashSet<>();
        pulses(p, 7, 1, i -> {
            ServerLevel l = p.serverLevel();
            dust(l, el, p.getX(), p.getY() + 0.9, p.getZ(), 6, 0.3, 1.4f);
            accent(l, el, p.getX(), p.getY() + 0.9, p.getZ(), 3, 0.3, 0.02);
            p.fallDistance = 0;
            if (dmg > 0) {
                for (LivingEntity e : around(p, p.position().add(0, 1, 0), 2.0)) {
                    if (done.add(e.getUUID())) {
                        hurt(p, e, dmg);
                        if (fx != null) {
                            fx.accept(e);
                        }
                    }
                }
            }
        });
    }

    public static boolean teleport(ServerPlayer p, Element el, double dist) {
        ServerLevel l = p.serverLevel();
        Vec3 from = p.position();
        Vec3 look = p.getLookAngle();
        Vec3 start = p.getEyePosition();
        Vec3 end = start.add(look.scale(dist));
        BlockHitResult bh = l.clip(new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        double d = dist;
        if (bh.getType() != HitResult.Type.MISS) {
            d = Math.max(0, start.distanceTo(bh.getLocation()) - 1.0);
        }
        for (double t = d; t >= 1.5; t -= 1.0) {
            Vec3 dest = from.add(look.scale(t));
            if (p.randomTeleport(dest.x, dest.y, dest.z, true)) {
                p.fallDistance = 0;
                dust(l, el, from.x, from.y + 1, from.z, 25, 0.4, 1.4f);
                accent(l, el, from.x, from.y + 1, from.z, 15, 0.4, 0.1);
                dust(l, el, p.getX(), p.getY() + 1, p.getZ(), 25, 0.4, 1.4f);
                accent(l, el, p.getX(), p.getY() + 1, p.getZ(), 15, 0.4, 0.1);
                l.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 0.7f, 1.3f);
                return true;
            }
        }
        return false;
    }

    public static void strike(ServerPlayer p, Element el, Vec3 pos, float dmg, double radius, Consumer<LivingEntity> fx) {
        ServerLevel l = p.serverLevel();
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(l);
        if (bolt != null) {
            bolt.moveTo(pos.x, pos.y, pos.z);
            bolt.setVisualOnly(true);
            l.addFreshEntity(bolt);
        }
        area(p, el, pos, radius, dmg, 0.2, fx);
    }

    public static void chain(ServerPlayer p, Element el, LivingEntity first, int jumps, float dmg, double range) {
        ServerLevel l = p.serverLevel();
        Set<UUID> done = new HashSet<>();
        done.add(first.getUUID());
        LivingEntity cur = first;
        for (int i = 0; i < jumps; i++) {
            LivingEntity next = null;
            double best = Double.MAX_VALUE;
            for (LivingEntity e : around(p, cur.position(), range)) {
                if (done.contains(e.getUUID())) {
                    continue;
                }
                double d = cur.distanceToSqr(e);
                if (d < best) {
                    best = d;
                    next = e;
                }
            }
            if (next == null) {
                break;
            }
            line(l, el, cur.getEyePosition(), next.getEyePosition());
            hurt(p, next, dmg);
            eff(next, net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN, 2, 2);
            done.add(next.getUUID());
            cur = next;
        }
    }

    public static void healAllies(ServerPlayer p, Element el, double radius, float amount) {
        ServerLevel l = p.serverLevel();
        for (Player o : l.getEntitiesOfClass(Player.class, p.getBoundingBox().inflate(radius))) {
            o.heal(amount);
            dust(l, el, o.getX(), o.getY() + 1, o.getZ(), 14, 0.5, 1.3f);
            accent(l, el, o.getX(), o.getY() + 1.2, o.getZ(), 8, 0.4, 0.05);
        }
        ring(l, el, p.position(), radius);
    }

    public static void deflect(ServerPlayer p, double radius) {
        for (Projectile pr : p.serverLevel().getEntitiesOfClass(Projectile.class, p.getBoundingBox().inflate(radius))) {
            if (pr.getOwner() != p) {
                pr.setDeltaMovement(pr.getDeltaMovement().scale(-1));
                pr.setOwner(p);
                pr.hurtMarked = true;
            }
        }
    }

    public static void swirl(ServerLevel l, Element el, Vec3 c, double radius, int tick) {
        for (int k = 0; k < 14; k++) {
            double a = tick * 0.6 + k * 0.55;
            double r = radius * (0.25 + 0.75 * k / 14.0);
            dust(l, el, c.x + Math.cos(a) * r, c.y + 0.2 + k * 0.22, c.z + Math.sin(a) * r, 1, 0.05, 1.3f);
            if (k % 3 == 0) {
                accent(l, el, c.x + Math.cos(a) * r, c.y + 0.2 + k * 0.22, c.z + Math.sin(a) * r, 1, 0.05, 0.02);
            }
        }
    }
}
