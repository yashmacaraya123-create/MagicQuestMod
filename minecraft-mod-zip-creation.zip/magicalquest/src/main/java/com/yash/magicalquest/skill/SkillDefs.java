package com.yash.magicalquest.skill;

import com.yash.magicalquest.element.Element;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

import static com.yash.magicalquest.skill.Fx.*;
import static com.yash.magicalquest.skill.Skill.Icon.*;
import static net.minecraft.world.effect.MobEffects.*;

/**
 * Every skill in the mod. Each element has 10 skills, one per icon shape.
 * Skill #1 (index 0) is given on awakening; skills #2-#10 are unlocked through quests.
 */
final class SkillDefs {
    private SkillDefs() {
    }

    static void registerAll() {
        fire();
        water();
        earth();
        wind();
        light();
        lightning();
        dark();
    }

    private static Consumer<LivingEntity> burn(int seconds) {
        return t -> t.setSecondsOnFire(seconds);
    }

    private static void removeBad(ServerPlayer p) {
        List<net.minecraft.world.effect.MobEffect> bad = new ArrayList<>();
        p.getActiveEffects().forEach(e -> {
            if (!e.getEffect().isBeneficial()) {
                bad.add(e.getEffect());
            }
        });
        bad.forEach(p::removeEffect);
    }

    // =================================================================== FIRE
    private static void fire() {
        final Element E = Element.FIRE;
        Skills.def(E, "Fireball", "Hurl a blazing orb that explodes on impact and sets foes ablaze.",
                10, 16, ORB, (p, s) -> projectile(p, E, 1.5f, 7f, 2.6f, 0f, burn(5)));
        Skills.def(E, "Flame Dash", "Burst forward in a trail of fire, scorching everything you pass through.",
                16, 60, DASH, (p, s) -> dash(p, E, 1.7, 6f, burn(5)));
        Skills.def(E, "Flame Nova", "Release a ring of fire that blasts and burns every enemy around you.",
                26, 120, NOVA, (p, s) -> burst(p, E, 5.5, 10f, 1.0f, burn(6)));
        Skills.def(E, "Inferno Breath", "Exhale a roaring stream of flame that burns everything in front of you.",
                24, 90, BEAM, (p, s) -> pulses(p, 5, 3, i -> bolt(p, E, 9, 3.5f, 8, burn(5))));
        Skills.def(E, "Heat Aura", "Wrap yourself in flame: more strength, resistance and fire immunity for 30s.",
                30, 400, SHIELD, (p, s) -> {
                    eff(p, DAMAGE_BOOST, 30, 0);
                    eff(p, FIRE_RESISTANCE, 30, 0);
                    eff(p, DAMAGE_RESISTANCE, 30, 0);
                    aura(p, E);
                });
        Skills.def(E, "Phoenix Blessing", "Rise from the ashes. Heal and regenerate with the phoenix's warmth.",
                40, 600, HEART, (p, s) -> {
                    p.heal(10f);
                    eff(p, REGENERATION, 8, 1);
                    eff(p, FIRE_RESISTANCE, 20, 0);
                    aura(p, E);
                });
        Skills.def(E, "Magma Eruption", "Call magma from the ground at your target, launching foes into the air.",
                30, 160, SPIKE, (p, s) -> {
                    Vec3 c = aim(p, 24).pos();
                    area(p, E, c, 3.5, 12f, 0.8, burn(6));
                    column(p.serverLevel(), E, c, 4);
                });
        Skills.def(E, "Ember Step", "Vanish in a flash of flame, scorching everything where you stood.",
                20, 100, WARP, (p, s) -> {
                    area(p, E, p.position(), 2.8, 5f, 0, burn(4));
                    teleport(p, E, 10);
                });
        Skills.def(E, "Fire Tornado", "Summon a spinning pillar of fire that drags enemies in and burns them.",
                45, 300, VORTEX, (p, s) -> {
                    Vec3 c = aim(p, 24).pos();
                    ServerLevel l = p.serverLevel();
                    pulses(p, 10, 5, i -> {
                        swirl(l, E, c, 3.5, i);
                        pull(p, c, 5, 0.25);
                        area(p, E, c, 3, 3f, 0, burn(4));
                    });
                });
        Skills.def(E, "Meteor Storm", "Call down a rain of meteors on the target area. The ultimate fire magic.",
                80, 900, SUN, (p, s) -> {
                    Vec3 c = aim(p, 40).pos();
                    ServerLevel l = p.serverLevel();
                    for (int i = 0; i < 8; i++) {
                        final int n = i;
                        Scheduler.later(5 + i * 10, () -> {
                            Vec3 t = c.add((l.random.nextDouble() - 0.5) * 12, 0, (l.random.nextDouble() - 0.5) * 12);
                            for (int k = 0; k < 9; k++) {
                                dust(l, E, t.x, t.y + k * 3, t.z, 3, 0.3, 2.0f);
                                l.sendParticles(ParticleTypes.FLAME, t.x, t.y + k * 3, t.z, 3, 0.2, 0.2, 0.2, 0.02);
                            }
                            l.sendParticles(ParticleTypes.EXPLOSION, t.x, t.y + 0.5, t.z, 3, 1.0, 0.3, 1.0, 0.0);
                            area(p, E, t, 3.5, 14f, 0.4, burn(6));
                        });
                    }
                });
    }

    // ================================================================== WATER
    private static void water() {
        final Element E = Element.WATER;
        Skills.def(E, "Aqua Lance", "Fire a fast jet of pressurised water that slows whatever it hits.",
                8, 12, ORB, (p, s) -> projectile(p, E, 1.8f, 6f, 0f, 0f, t -> eff(t, MOVEMENT_SLOWDOWN, 3, 1)));
        Skills.def(E, "Aqua Dash", "Surge forward like a dolphin, hitting foes in your way.",
                15, 50, DASH, (p, s) -> {
                    dash(p, E, 1.5, 4f, t -> eff(t, MOVEMENT_SLOWDOWN, 2, 1));
                    eff(p, DOLPHINS_GRACE, 5, 0);
                    eff(p, WATER_BREATHING, 10, 0);
                });
        Skills.def(E, "Tidal Wave", "Send out a crushing wave that hurls every nearby enemy away.",
                25, 120, NOVA, (p, s) -> burst(p, E, 6, 8f, 1.8f, t -> eff(t, MOVEMENT_SLOWDOWN, 3, 1)));
        Skills.def(E, "Frost Ray", "A freezing beam that pierces enemies and locks them in ice.",
                20, 80, BEAM, (p, s) -> bolt(p, E, 14, 7f, 6, t -> {
                    eff(t, MOVEMENT_SLOWDOWN, 5, 2);
                    t.setTicksFrozen(t.getTicksRequiredToFreeze() + 80);
                }));
        Skills.def(E, "Aqua Shield", "A shell of living water: absorption, resistance and extinguished flames.",
                30, 400, SHIELD, (p, s) -> {
                    eff(p, ABSORPTION, 30, 2);
                    eff(p, DAMAGE_RESISTANCE, 20, 0);
                    p.clearFire();
                    aura(p, E);
                });
        Skills.def(E, "Healing Spring", "Conjure a spring that heals you and nearby allies.",
                40, 500, HEART, (p, s) -> {
                    healAllies(p, E, 7, 12f);
                    eff(p, REGENERATION, 10, 1);
                });
        Skills.def(E, "Ice Spike", "Spears of ice burst from the ground at your target.",
                28, 140, SPIKE, (p, s) -> {
                    Vec3 c = aim(p, 24).pos();
                    area(p, E, c, 3, 11f, 0.7, t -> {
                        eff(t, MOVEMENT_SLOWDOWN, 4, 2);
                        t.setTicksFrozen(t.getTicksRequiredToFreeze() + 60);
                    });
                    column(p.serverLevel(), E, c, 3);
                });
        Skills.def(E, "Mist Step", "Dissolve into mist, reappear further away and move unseen for a moment.",
                20, 120, WARP, (p, s) -> {
                    teleport(p, E, 12);
                    eff(p, INVISIBILITY, 3, 0);
                    eff(p, MOVEMENT_SPEED, 4, 1);
                });
        Skills.def(E, "Whirlpool", "A churning whirlpool drags enemies together and batters them.",
                45, 300, VORTEX, (p, s) -> {
                    Vec3 c = aim(p, 24).pos();
                    ServerLevel l = p.serverLevel();
                    pulses(p, 12, 4, i -> {
                        swirl(l, E, c, 4, i);
                        pull(p, c, 6, 0.3);
                        if (i % 2 == 0) {
                            area(p, E, c, 3.5, 2.5f, 0, null);
                        }
                    });
                });
        Skills.def(E, "Tsunami", "Summon a towering tidal wave. The ultimate water magic.",
                80, 900, SUN, (p, s) -> {
                    burst(p, E, 8, 14f, 2.2f, t -> eff(t, MOVEMENT_SLOWDOWN, 4, 1));
                    Scheduler.later(10, () -> {
                        if (p.isAlive()) {
                            burst(p, E, 12, 12f, 2.5f, t -> eff(t, MOVEMENT_SLOWDOWN, 4, 1));
                        }
                    });
                });
    }

    // ================================================================== EARTH
    private static void earth() {
        final Element E = Element.EARTH;
        Skills.def(E, "Boulder Toss", "Heave a heavy boulder that crashes down where it lands.",
                12, 25, ORB, (p, s) -> projectile(p, E, 1.2f, 10f, 2.0f, 0.03f, null));
        Skills.def(E, "Seismic Charge", "Charge forward with the weight of a mountain, knocking foes into the air.",
                18, 70, DASH, (p, s) -> dash(p, E, 1.4, 8f, t -> launch(t, 0.5)));
        Skills.def(E, "Quake", "Slam the ground, shaking and slowing all nearby enemies.",
                28, 140, NOVA, (p, s) -> burst(p, E, 6, 9f, 0.5f, t -> {
                    eff(t, MOVEMENT_SLOWDOWN, 3, 1);
                    launch(t, 0.45);
                }));
        Skills.def(E, "Crystal Lance", "Shoot a razor-sharp crystal lance that pierces up to three foes.",
                22, 90, BEAM, (p, s) -> bolt(p, E, 16, 13f, 3, null));
        Skills.def(E, "Stone Skin", "Harden your skin to stone: strong resistance and absorption for 25s.",
                30, 400, SHIELD, (p, s) -> {
                    eff(p, DAMAGE_RESISTANCE, 25, 1);
                    eff(p, ABSORPTION, 25, 1);
                    aura(p, E);
                });
        Skills.def(E, "Mountain Heart", "Gain the heart of a mountain: bonus health for a full minute.",
                40, 600, HEART, (p, s) -> {
                    eff(p, HEALTH_BOOST, 60, 2);
                    p.heal(10f);
                    eff(p, REGENERATION, 6, 0);
                    aura(p, E);
                });
        Skills.def(E, "Earth Spike", "A massive spike of rock erupts at your target.",
                30, 150, SPIKE, (p, s) -> {
                    Vec3 c = aim(p, 24).pos();
                    area(p, E, c, 2.5, 14f, 1.0, null);
                    column(p.serverLevel(), E, c, 3);
                });
        Skills.def(E, "Burrow Step", "Sink into the earth and surface a short way ahead, hardened for a moment.",
                18, 100, WARP, (p, s) -> {
                    teleport(p, E, 8);
                    eff(p, DAMAGE_RESISTANCE, 3, 2);
                });
        Skills.def(E, "Rock Storm", "A whirling storm of rubble pummels everything in the target area.",
                48, 320, VORTEX, (p, s) -> {
                    Vec3 c = aim(p, 24).pos();
                    ServerLevel l = p.serverLevel();
                    pulses(p, 8, 5, i -> {
                        swirl(l, E, c, 4, i);
                        l.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.STONE.defaultBlockState()),
                                c.x, c.y + 2, c.z, 40, 1.8, 1.2, 1.8, 0.1);
                        area(p, E, c, 4, 5f, 0.3, null);
                    });
                });
        Skills.def(E, "Titan's Wrath", "The earth itself rises in fury. The ultimate earth magic.",
                85, 950, SUN, (p, s) -> {
                    burst(p, E, 10, 22f, 0.8f, t -> {
                        launch(t, 1.0);
                        eff(t, WEAKNESS, 8, 1);
                        eff(t, MOVEMENT_SLOWDOWN, 5, 2);
                    });
                    eff(p, ABSORPTION, 15, 2);
                    aura(p, E);
                });
    }

    // =================================================================== WIND
    private static void wind() {
        final Element E = Element.WIND;
        Skills.def(E, "Wind Blade", "Launch a fast, thin blade of compressed air.",
                8, 10, ORB, (p, s) -> projectile(p, E, 2.2f, 6f, 0f, 0f, t -> knock(t.position().subtract(p.getLookAngle()), t, 0.4, 0.2)));
        Skills.def(E, "Gale Dash", "Ride the gale in a lightning-fast dash.",
                12, 45, DASH, (p, s) -> {
                    dash(p, E, 2.2, 4f, null);
                    eff(p, SLOW_FALLING, 3, 0);
                });
        Skills.def(E, "Gust Burst", "Release a powerful gust that blasts all nearby enemies away.",
                22, 100, NOVA, (p, s) -> burst(p, E, 6, 5f, 2.0f, null));
        Skills.def(E, "Razor Wind", "A long cutting wind that slices through every enemy in a line.",
                20, 70, BEAM, (p, s) -> bolt(p, E, 14, 6f, 10, null));
        Skills.def(E, "Wind Barrier", "A barrier of air that reflects projectiles and lightens your steps.",
                28, 380, SHIELD, (p, s) -> {
                    deflect(p, 6);
                    eff(p, DAMAGE_RESISTANCE, 20, 0);
                    eff(p, SLOW_FALLING, 20, 0);
                    eff(p, MOVEMENT_SPEED, 20, 0);
                    aura(p, E);
                });
        Skills.def(E, "Refreshing Breeze", "A gentle breeze that heals and quickens you and your allies.",
                35, 450, HEART, (p, s) -> {
                    healAllies(p, E, 6, 8f);
                    eff(p, REGENERATION, 10, 1);
                    eff(p, MOVEMENT_SPEED, 10, 1);
                });
        Skills.def(E, "Cyclone Strike", "A sudden cyclone at your target throws enemies skyward.",
                28, 140, SPIKE, (p, s) -> {
                    Vec3 c = aim(p, 24).pos();
                    area(p, E, c, 3, 9f, 1.2, null);
                    column(p.serverLevel(), E, c, 4);
                });
        Skills.def(E, "Sky Step", "Leap high into the sky and glide back down gently.",
                15, 100, WARP, (p, s) -> {
                    Vec3 look = p.getLookAngle();
                    p.setDeltaMovement(look.x * 0.6, 1.35, look.z * 0.6);
                    p.hurtMarked = true;
                    p.fallDistance = 0;
                    eff(p, SLOW_FALLING, 8, 0);
                    aura(p, E);
                });
        Skills.def(E, "Tornado", "Raise a tornado that lifts and shreds enemies in its path.",
                45, 300, VORTEX, (p, s) -> {
                    Vec3 c = aim(p, 24).pos();
                    ServerLevel l = p.serverLevel();
                    pulses(p, 10, 5, i -> {
                        swirl(l, E, c, 4, i);
                        pull(p, c, 5, 0.2);
                        for (LivingEntity e : around(p, c, 4)) {
                            hurt(p, e, 2.5f);
                            launch(e, 0.45);
                        }
                    });
                });
        Skills.def(E, "Heaven's Gale", "A storm that rips through the sky. The ultimate wind magic.",
                80, 900, SUN, (p, s) -> {
                    burst(p, E, 11, 16f, 2.6f, t -> {
                        launch(t, 0.8);
                        eff(t, LEVITATION, 2, 0);
                    });
                    eff(p, MOVEMENT_SPEED, 20, 2);
                    eff(p, JUMP, 20, 2);
                    eff(p, SLOW_FALLING, 20, 0);
                    aura(p, E);
                });
    }

    // ================================================================== LIGHT
    private static Consumer<LivingEntity> smite(ServerPlayer p, float bonus) {
        return t -> {
            if (t.getMobType() == MobType.UNDEAD) {
                hurt(p, t, bonus);
                t.setSecondsOnFire(4);
            }
        };
    }

    private static void light() {
        final Element E = Element.LIGHT;
        Skills.def(E, "Holy Bolt", "A bolt of holy light. Deals bonus damage to the undead.",
                10, 12, ORB, (p, s) -> projectile(p, E, 1.9f, 6f, 0f, 0f, smite(p, 6f)));
        Skills.def(E, "Radiant Dash", "Dash in a flash of light, dazzling and revealing those you strike.",
                14, 60, DASH, (p, s) -> dash(p, E, 1.8, 5f, t -> {
                    eff(t, BLINDNESS, 2, 0);
                    eff(t, GLOWING, 8, 0);
                }));
        Skills.def(E, "Holy Nova", "A wave of radiance that harms enemies and mends allies.",
                28, 130, NOVA, (p, s) -> {
                    burst(p, E, 6, 7f, 0.6f, smite(p, 7f));
                    healAllies(p, E, 6, 4f);
                });
        Skills.def(E, "Sunbeam", "A long, piercing beam of sunlight. The undead burn in it.",
                25, 100, BEAM, (p, s) -> bolt(p, E, 22, 12f, 6, smite(p, 6f)));
        Skills.def(E, "Guardian Barrier", "A shining barrier grants absorption and resistance.",
                30, 400, SHIELD, (p, s) -> {
                    eff(p, ABSORPTION, 30, 2);
                    eff(p, DAMAGE_RESISTANCE, 15, 1);
                    aura(p, E);
                });
        Skills.def(E, "Healing Light", "Warm light heals you and nearby allies.",
                40, 450, HEART, (p, s) -> {
                    healAllies(p, E, 8, 14f);
                    eff(p, REGENERATION, 6, 1);
                });
        Skills.def(E, "Pillar of Light", "A pillar of holy light strikes your target area. Heavy damage to undead.",
                30, 150, SPIKE, (p, s) -> {
                    Vec3 c = aim(p, 24).pos();
                    area(p, E, c, 3, 12f, 0.3, smite(p, 12f));
                    column(p.serverLevel(), E, c, 8);
                });
        Skills.def(E, "Divine Step", "Step through a ray of light to a place far ahead.",
                20, 100, WARP, (p, s) -> {
                    teleport(p, E, 16);
                    eff(p, MOVEMENT_SPEED, 4, 1);
                });
        Skills.def(E, "Sanctuary", "Create a holy ground that heals allies and sears the undead for five seconds.",
                50, 500, VORTEX, (p, s) -> {
                    Vec3 c = p.position();
                    ServerLevel l = p.serverLevel();
                    pulses(p, 10, 10, i -> {
                        swirl(l, E, c, 5, i);
                        ring(l, E, c, 6);
                        for (Player o : l.getEntitiesOfClass(Player.class, new net.minecraft.world.phys.AABB(c, c).inflate(6))) {
                            o.heal(2f);
                        }
                        for (LivingEntity e : around(p, c, 6)) {
                            if (e.getMobType() == MobType.UNDEAD) {
                                hurt(p, e, 3f);
                            }
                        }
                    });
                });
        Skills.def(E, "Dawn Judgment", "Beams of dawn descend on every nearby foe. The ultimate light magic.",
                85, 1000, SUN, (p, s) -> {
                    List<LivingEntity> targets = new ArrayList<>();
                    for (LivingEntity e : around(p, p.position(), 14)) {
                        if (e instanceof Enemy) {
                            targets.add(e);
                        }
                    }
                    ServerLevel l = p.serverLevel();
                    int i = 0;
                    for (LivingEntity e : targets) {
                        if (i++ >= 12) {
                            break;
                        }
                        final LivingEntity target = e;
                        Scheduler.later(3 + i * 3, () -> {
                            if (target.isAlive()) {
                                column(l, E, target.position(), 12);
                                hurt(p, target, 20f);
                                smite(p, 10f).accept(target);
                                impactSound(l, E, target.position(), 0.7f);
                            }
                        });
                    }
                    p.heal(10f);
                    removeBad(p);
                    aura(p, E);
                });
    }

    // ============================================================= LIGHTNING
    private static void lightning() {
        final Element E = Element.LIGHTNING;
        Skills.def(E, "Spark Bolt", "A crackling spark that briefly stuns the target.",
                8, 10, ORB, (p, s) -> projectile(p, E, 2.4f, 6f, 0f, 0f, t -> eff(t, MOVEMENT_SLOWDOWN, 1, 3)));
        Skills.def(E, "Volt Dash", "Move at the speed of lightning, shocking everyone you pass.",
                14, 50, DASH, (p, s) -> {
                    dash(p, E, 2.0, 6f, null);
                    eff(p, MOVEMENT_SPEED, 3, 1);
                });
        Skills.def(E, "Static Field", "Charge the air around you, weakening and slowing nearby enemies.",
                25, 130, NOVA, (p, s) -> burst(p, E, 5, 8f, 0.4f, t -> {
                    eff(t, WEAKNESS, 5, 1);
                    eff(t, MOVEMENT_SLOWDOWN, 3, 1);
                }));
        Skills.def(E, "Chain Lightning", "A bolt that leaps from enemy to enemy, up to five targets.",
                22, 90, BEAM, (p, s) -> {
                    List<LivingEntity> hit = bolt(p, E, 18, 8f, 1, null);
                    if (!hit.isEmpty()) {
                        chain(p, E, hit.get(0), 4, 7f, 7);
                    }
                });
        Skills.def(E, "Overcharge", "Overcharge your body with speed, haste and strength for 25s.",
                30, 420, SHIELD, (p, s) -> {
                    eff(p, MOVEMENT_SPEED, 25, 1);
                    eff(p, DIG_SPEED, 25, 1);
                    eff(p, DAMAGE_BOOST, 25, 0);
                    aura(p, E);
                });
        Skills.def(E, "Galvanic Pulse", "A soothing electric pulse that mends wounds and quickens the body.",
                35, 450, HEART, (p, s) -> {
                    healAllies(p, E, 6, 8f);
                    eff(p, REGENERATION, 6, 2);
                    eff(p, DIG_SPEED, 10, 0);
                });
        Skills.def(E, "Thunder Strike", "Call a bolt of lightning at your target, stunning anything it hits.",
                30, 140, SPIKE, (p, s) -> strike(p, E, aim(p, 28).pos(), 16f, 2.6, t -> eff(t, MOVEMENT_SLOWDOWN, 2, 3)));
        Skills.def(E, "Lightning Step", "Teleport in a flash of lightning, zapping those near your starting point.",
                18, 90, WARP, (p, s) -> {
                    area(p, E, p.position(), 2.8, 6f, 0, null);
                    teleport(p, E, 14);
                });
        Skills.def(E, "Storm Call", "Summon a storm that rains lightning on your target area.",
                50, 350, VORTEX, (p, s) -> {
                    Vec3 c = aim(p, 28).pos();
                    ServerLevel l = p.serverLevel();
                    pulses(p, 8, 5, i -> strike(p, E,
                            c.add((l.random.nextDouble() - 0.5) * 12, 0, (l.random.nextDouble() - 0.5) * 12), 9f, 2.4, null));
                });
        Skills.def(E, "Raijin's Wrath", "Unleash the wrath of the thunder god. The ultimate lightning magic.",
                90, 1000, SUN, (p, s) -> {
                    ServerLevel l = p.serverLevel();
                    List<LivingEntity> targets = around(p, p.position(), 14);
                    for (int i = 0; i < 12; i++) {
                        final Vec3 pos = i < targets.size()
                                ? targets.get(i).position()
                                : p.position().add((l.random.nextDouble() - 0.5) * 24, 0, (l.random.nextDouble() - 0.5) * 24);
                        Scheduler.later(2 + i * 3, () -> {
                            if (p.isAlive()) {
                                strike(p, E, pos, 18f, 2.6, null);
                            }
                        });
                    }
                    eff(p, MOVEMENT_SPEED, 15, 2);
                    aura(p, E);
                });
    }

    // =================================================================== DARK
    private static void dark() {
        final Element E = Element.DARK;
        Skills.def(E, "Shadow Bolt", "A bolt of living shadow that withers whatever it touches.",
                9, 12, ORB, (p, s) -> projectile(p, E, 1.7f, 6f, 0f, 0f, t -> eff(t, WITHER, 4, 0)));
        Skills.def(E, "Shadow Dash", "Dissolve into shadow and dash through foes, unseen.",
                14, 50, DASH, (p, s) -> {
                    dash(p, E, 1.9, 5f, null);
                    eff(p, INVISIBILITY, 3, 0);
                });
        Skills.def(E, "Soul Burst", "A burst of soul energy that blinds and weakens nearby enemies.",
                26, 130, NOVA, (p, s) -> burst(p, E, 5.5, 8f, 0.5f, t -> {
                    eff(t, BLINDNESS, 4, 0);
                    eff(t, WEAKNESS, 5, 0);
                }));
        Skills.def(E, "Life Drain", "Tear life force from a foe and add it to your own.",
                22, 80, BEAM, (p, s) -> {
                    List<LivingEntity> hit = bolt(p, E, 12, 8f, 1, null);
                    if (!hit.isEmpty()) {
                        p.heal(6f);
                        dust(p.serverLevel(), E, p.getX(), p.getY() + 1.2, p.getZ(), 15, 0.4, 1.3f);
                    }
                });
        Skills.def(E, "Umbral Veil", "Wrap yourself in shadow: invisible, quick and shielded for 12s.",
                30, 420, SHIELD, (p, s) -> {
                    eff(p, INVISIBILITY, 12, 0);
                    eff(p, DAMAGE_RESISTANCE, 12, 0);
                    eff(p, ABSORPTION, 12, 1);
                    eff(p, MOVEMENT_SPEED, 12, 0);
                    aura(p, E);
                });
        Skills.def(E, "Vampiric Rite", "A dark rite that heals you greatly, at the cost of a little hunger.",
                35, 450, HEART, (p, s) -> {
                    p.heal(14f);
                    eff(p, REGENERATION, 5, 1);
                    eff(p, HUNGER, 5, 0);
                    aura(p, E);
                });
        Skills.def(E, "Curse of Ruin", "Lay a curse on the target area: wither, weakness and damage.",
                30, 160, SPIKE, (p, s) -> {
                    Vec3 c = aim(p, 24).pos();
                    area(p, E, c, 4, 8f, 0, t -> {
                        eff(t, WITHER, 6, 1);
                        eff(t, WEAKNESS, 8, 1);
                    });
                    column(p.serverLevel(), E, c, 3);
                });
        Skills.def(E, "Shadow Step", "Slip through the shadows to a place far ahead.",
                18, 90, WARP, (p, s) -> {
                    teleport(p, E, 14);
                    eff(p, INVISIBILITY, 2, 0);
                });
        Skills.def(E, "Void Grasp", "A void opens and drags everything nearby toward its centre.",
                45, 300, VORTEX, (p, s) -> {
                    Vec3 c = aim(p, 24).pos();
                    ServerLevel l = p.serverLevel();
                    pulses(p, 10, 5, i -> {
                        swirl(l, E, c, 4, i);
                        pull(p, c, 8, 0.5);
                        for (LivingEntity e : around(p, c, 3)) {
                            hurt(p, e, 3.5f);
                        }
                    });
                });
        Skills.def(E, "Eclipse", "Plunge the area into an eclipse. The ultimate dark magic.",
                90, 1000, SUN, (p, s) -> {
                    burst(p, E, 12, 14f, 0.4f, t -> {
                        eff(t, BLINDNESS, 6, 0);
                        eff(t, WITHER, 8, 1);
                        eff(t, WEAKNESS, 8, 1);
                    });
                    p.heal(10f);
                    eff(p, DAMAGE_BOOST, 15, 1);
                    eff(p, REGENERATION, 6, 1);
                    aura(p, E);
                });
    }
}
