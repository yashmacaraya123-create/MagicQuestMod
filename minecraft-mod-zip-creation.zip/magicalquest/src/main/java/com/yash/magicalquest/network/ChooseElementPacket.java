package com.yash.magicalquest.network;

import com.yash.magicalquest.element.Element;
import com.yash.magicalquest.magic.SkillManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: chosen element ordinal, or -1 to cancel a rebirth. */
public record ChooseElementPacket(int ordinal) {
    public static void encode(ChooseElementPacket msg, FriendlyByteBuf buf) {
        buf.writeVarInt(msg.ordinal + 1);
    }

    public static ChooseElementPacket decode(FriendlyByteBuf buf) {
        return new ChooseElementPacket(buf.readVarInt() - 1);
    }

    public static void handle(ChooseElementPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player == null) {
                return;
            }
            if (msg.ordinal < 0) {
                SkillManager.cancelRebirth(player);
            } else {
                SkillManager.choose(player, Element.byOrdinal(msg.ordinal));
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
