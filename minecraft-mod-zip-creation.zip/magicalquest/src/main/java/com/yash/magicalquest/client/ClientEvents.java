package com.yash.magicalquest.client;

import com.yash.magicalquest.MagicalQuest;
import com.yash.magicalquest.client.screen.SkillWheelScreen;
import com.yash.magicalquest.client.screen.StatusScreen;
import com.yash.magicalquest.magic.PlayerMagic;
import com.yash.magicalquest.network.CastSkillPacket;
import com.yash.magicalquest.network.Net;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Client-only Forge bus events: key handling. */
@Mod.EventBusSubscriber(modid = MagicalQuest.MODID, value = Dist.CLIENT)
public final class ClientEvents {
    private ClientEvents() {
    }

    @SubscribeEvent
    public static void clientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return;
        }
        ClientHooks.applyPending();
        PlayerMagic m = PlayerMagic.get(mc.player);

        while (ClientKeys.CAST.consumeClick()) {
            if (mc.screen == null && m.chosen) {
                Net.toServer(new CastSkillPacket());
            }
        }
        while (ClientKeys.WHEEL.consumeClick()) {
            if (mc.screen == null && m.chosen) {
                mc.setScreen(new SkillWheelScreen());
            }
        }
        while (ClientKeys.STATUS.consumeClick()) {
            if (mc.screen == null && m.chosen) {
                mc.setScreen(new StatusScreen());
            }
        }
    }
}
