package com.yash.magicalquest.registry;

import com.yash.magicalquest.MagicalQuest;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MagicalQuest.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.magicalquest"))
            .icon(() -> new ItemStack(ModItems.REBIRTH_CRYSTAL.get()))
            .displayItems((params, output) -> {
                output.accept(ModItems.REBIRTH_CRYSTAL.get());
                output.accept(ModItems.MANA_POTION.get());
                output.accept(ModItems.MANA_SHARD.get());
                output.accept(ModItems.MAGE_STAFF.get());
                ModItems.CHARMS.values().forEach(c -> output.accept(c.get()));
                output.accept(ModItems.MAGE_SPAWN_EGG.get());
            })
            .build());

    private ModTabs() {
    }
}
