package com.yash.magicalquest.client;

import com.yash.magicalquest.client.screen.DialogScreen;
import com.yash.magicalquest.client.screen.ElementSelectScreen;
import com.yash.magicalquest.magic.PlayerMagic;
import com.yash.magicalquest.network.OpenDialogPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;

/** Entry points called by network packets on the client. Only loaded on the client. */
public final class ClientHooks {
    private static CompoundTag pending;

    private ClientHooks() {
    }

    public static void sync(CompoundTag tag) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            pending = tag;
            return;
        }
        PlayerMagic.get(mc.player).load(tag);
    }

    public static void applyPending() {
        Minecraft mc = Minecraft.getInstance();
        if (pending != null && mc.player != null) {
            PlayerMagic.get(mc.player).load(pending);
            pending = null;
        }
    }

    public static void openElementSelect(boolean rebirth) {
        Minecraft.getInstance().setScreen(new ElementSelectScreen(rebirth));
    }

    public static void openDialog(OpenDialogPacket packet) {
        Minecraft.getInstance().setScreen(new DialogScreen(packet));
    }
}
