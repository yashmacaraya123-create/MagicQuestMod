package com.yash.magicalquest.magic;

import com.yash.magicalquest.element.Element;
import com.yash.magicalquest.network.Net;
import com.yash.magicalquest.network.OpenElementSelectPacket;
import com.yash.magicalquest.quest.Quest;
import com.yash.magicalquest.quest.Quests;
import com.yash.magicalquest.registry.ModItems;
import com.yash.magicalquest.skill.Fx;
import com.yash.magicalquest.skill.Skill;
import com.yash.magicalquest.skill.Skills;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;

import java.util.List;

/** Server-side logic for choosing an element, selecting and casting skills. */
public final class SkillManager {
    private SkillManager() {
    }

    public static void title(ServerPlayer p, Component title, Component subtitle) {
        p.connection.send(new ClientboundSetTitlesAnimationPacket(10, 70, 20));
        p.connection.send(new ClientboundSetSubtitleTextPacket(subtitle));
        p.connection.send(new ClientboundSetTitleTextPacket(title));
    }

    public static void bar(ServerPlayer p, String text, ChatFormatting color) {
        p.displayClientMessage(Component.literal(text).withStyle(color), true);
    }

    /** Called when a player joins and has not awakened yet. */
    public static void promptIfNeeded(ServerPlayer p) {
        PlayerMagic m = PlayerMagic.get(p);
        if (!m.chosen) {
            Net.toPlayer(p, new OpenElementSelectPacket(false));
        }
    }

    /** Called by the Rebirth Crystal. */
    public static void openRebirth(ServerPlayer p) {
        PlayerMagic m = PlayerMagic.get(p);
        if (!m.chosen) {
            Net.toPlayer(p, new OpenElementSelectPacket(false));
            return;
        }
        m.rebirthPending = true;
        Net.toPlayer(p, new OpenElementSelectPacket(true));
    }

    public static void cancelRebirth(ServerPlayer p) {
        PlayerMagic m = PlayerMagic.get(p);
        if (m.rebirthPending) {
            m.rebirthPending = false;
            MagicCaps.sync(p);
        }
    }

    public static void choose(ServerPlayer p, Element element) {
        PlayerMagic m = PlayerMagic.get(p);
        boolean first = !m.chosen;
        if (!first) {
            if (!m.rebirthPending) {
                return;
            }
            if (!consumeCrystal(p)) {
                m.rebirthPending = false;
                bar(p, "You need a Rebirth Crystal to change your element.", ChatFormatting.RED);
                MagicCaps.sync(p);
                return;
            }
        }
        m.chosen = true;
        m.rebirthPending = false;
        m.element = element;

        Quest active = Quests.get(m.activeQuest);
        if (active != null && active.element != null && active.element != element) {
            m.activeQuest = "";
            m.progress = 0;
        }

        Skill starter = Skills.of(element).get(0);
        m.unlocked.add(starter.id);
        Skill sel = Skills.get(m.selected);
        if (sel == null || sel.element != element || !m.unlocked.contains(sel.id)) {
            m.selected = starter.id;
        }
        m.mana = m.maxMana();
        MagicCaps.sync(p);

        Component name = Component.literal(element.displayName).withStyle(Style.EMPTY.withColor(element.color).withBold(true));
        title(p, Component.literal("You are now a ").append(name).append(" mage"),
                Component.literal(first ? "Your second life begins..." : "Your fate has been rewritten.")
                        .withStyle(ChatFormatting.GRAY));
        p.level().playSound(null, p.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1f, 0.8f);
        if (first) {
            p.sendSystemMessage(Component.literal("[Goddess] ").withStyle(ChatFormatting.LIGHT_PURPLE)
                    .append(Component.literal("Seek out a Village Mage to begin your quests. "
                            + "Hold [R] for the skill wheel, press [Z] to cast, [K] for your status.")
                            .withStyle(ChatFormatting.GRAY)));
            giveStarterGuide(p);
        }
    }

    private static void giveStarterGuide(ServerPlayer p) {
        ItemStack potions = new ItemStack(ModItems.MANA_POTION.get(), 2);
        if (!p.getInventory().add(potions)) {
            p.drop(potions, false);
        }
    }

    private static boolean consumeCrystal(ServerPlayer p) {
        if (p.getAbilities().instabuild) {
            return true;
        }
        for (int i = 0; i < p.getInventory().getContainerSize(); i++) {
            ItemStack st = p.getInventory().getItem(i);
            if (st.is(ModItems.REBIRTH_CRYSTAL.get())) {
                st.shrink(1);
                return true;
            }
        }
        return false;
    }

    public static void select(ServerPlayer p, String skillId) {
        PlayerMagic m = PlayerMagic.get(p);
        Skill s = Skills.get(skillId);
        if (s == null || !m.chosen || s.element != m.element || !m.unlocked.contains(s.id)) {
            return;
        }
        m.selected = s.id;
        MagicCaps.sync(p);
    }

    public static List<Skill> unlockedSkills(PlayerMagic m) {
        return Skills.of(m.element).stream().filter(s -> m.unlocked.contains(s.id)).toList();
    }

    public static void cast(ServerPlayer p, float costMultiplier) {
        PlayerMagic m = PlayerMagic.get(p);
        if (!m.chosen) {
            return;
        }
        Skill s = Skills.get(m.selected);
        if (s == null || s.element != m.element || !m.unlocked.contains(s.id)) {
            bar(p, "No skill selected. Hold [R] to open the skill wheel.", ChatFormatting.RED);
            return;
        }
        int cd = m.cooldown(s.id);
        if (cd > 0) {
            bar(p, s.name + " is recharging (" + String.format("%.1f", cd / 20f) + "s)", ChatFormatting.GRAY);
            return;
        }
        int cost = Math.round(s.manaCost * costMultiplier);
        if (m.mana < cost) {
            bar(p, "Not enough mana! (" + (int) m.mana + "/" + cost + ")", ChatFormatting.RED);
            return;
        }
        m.mana -= cost;
        m.cooldowns.put(s.id, s.cooldown);
        Fx.castSound(p, s.element);
        s.caster.cast(p, s);
        p.displayClientMessage(Component.literal(s.name).withStyle(Style.EMPTY.withColor(s.element.color)), true);
        MagicCaps.sync(p);
    }
}
