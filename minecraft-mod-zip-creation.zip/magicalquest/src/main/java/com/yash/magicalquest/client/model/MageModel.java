package com.yash.magicalquest.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.yash.magicalquest.MagicalQuest;
import com.yash.magicalquest.entity.MageEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Original model for the Village Mage: pointed hat with a bent tip, flowing robe, cape,
 * a long staff with a gem and a small floating mana orb. Texture is 128x64.
 */
public class MageModel extends EntityModel<MageEntity> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(MagicalQuest.MODID, "mage"), "main");

    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart rightArm;
    private final ModelPart leftArm;
    private final ModelPart rightBoot;
    private final ModelPart leftBoot;
    private final ModelPart orb;
    private final ModelPart staff;

    public MageModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.rightArm = root.getChild("right_arm");
        this.leftArm = root.getChild("left_arm");
        this.rightBoot = root.getChild("right_boot");
        this.leftBoot = root.getChild("left_boot");
        this.orb = root.getChild("orb");
        this.staff = rightArm.getChild("staff");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        PartDefinition head = root.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 0).addBox(-4f, -8f, -4f, 8f, 8f, 8f), PartPose.ZERO);
        head.addOrReplaceChild("nose",
                CubeListBuilder.create().texOffs(40, 16).addBox(-1f, -4f, -6f, 2f, 3f, 2f), PartPose.ZERO);
        head.addOrReplaceChild("hat_brim",
                CubeListBuilder.create().texOffs(32, 0).addBox(-7f, -9f, -7f, 14f, 1f, 14f), PartPose.ZERO);
        head.addOrReplaceChild("hat_base",
                CubeListBuilder.create().texOffs(88, 0).addBox(-4f, -13f, -4f, 8f, 4f, 8f), PartPose.ZERO);
        head.addOrReplaceChild("hat_mid",
                CubeListBuilder.create().texOffs(0, 16).addBox(-3f, -17f, -3f, 6f, 4f, 6f), PartPose.ZERO);
        head.addOrReplaceChild("hat_tip",
                CubeListBuilder.create().texOffs(24, 16).addBox(-1.5f, -3f, -1.5f, 3f, 3f, 3f),
                PartPose.offsetAndRotation(0f, -17f, 0f, 0.0f, 0.0f, 0.45f));

        root.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(0, 28).addBox(-4f, 0f, -2f, 8f, 12f, 4f), PartPose.ZERO);
        root.addOrReplaceChild("robe",
                CubeListBuilder.create().texOffs(24, 28).addBox(-5f, 10f, -3f, 10f, 14f, 6f), PartPose.ZERO);
        root.addOrReplaceChild("cape",
                CubeListBuilder.create().texOffs(0, 46).addBox(-4f, 1f, 3f, 8f, 14f, 1f), PartPose.ZERO);

        PartDefinition rightArm = root.addOrReplaceChild("right_arm",
                CubeListBuilder.create().texOffs(56, 28).addBox(-3f, -2f, -2f, 4f, 8f, 4f),
                PartPose.offset(-5f, 2f, 0f));
        rightArm.addOrReplaceChild("staff",
                CubeListBuilder.create()
                        .texOffs(106, 34).addBox(-0.5f, -14f, -0.5f, 1f, 26f, 1f)
                        .texOffs(106, 28).addBox(-1.5f, -17f, -1.5f, 3f, 3f, 3f),
                PartPose.offset(-1f, 6f, -1f));
        root.addOrReplaceChild("left_arm",
                CubeListBuilder.create().texOffs(72, 28).addBox(-1f, -2f, -2f, 4f, 8f, 4f),
                PartPose.offset(5f, 2f, 0f));

        root.addOrReplaceChild("right_boot",
                CubeListBuilder.create().texOffs(88, 28).addBox(-2f, 22f, -3f, 4f, 2f, 5f), PartPose.offset(-2f, 0f, 0f));
        root.addOrReplaceChild("left_boot",
                CubeListBuilder.create().texOffs(88, 28).mirror().addBox(-2f, 22f, -3f, 4f, 2f, 5f), PartPose.offset(2f, 0f, 0f));

        root.addOrReplaceChild("orb",
                CubeListBuilder.create().texOffs(106, 28).addBox(-1.5f, -1.5f, -1.5f, 3f, 3f, 3f),
                PartPose.offset(-9f, -4f, -2f));

        return LayerDefinition.create(mesh, 128, 64);
    }

    @Override
    public void setupAnim(MageEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        head.yRot = netHeadYaw * ((float) Math.PI / 180f);
        head.xRot = headPitch * ((float) Math.PI / 180f);

        float idle = Mth.sin(ageInTicks * 0.067f) * 0.05f;
        rightArm.xRot = -0.85f + Mth.cos(limbSwing * 0.6662f + (float) Math.PI) * 0.5f * limbSwingAmount + idle;
        rightArm.yRot = 0.25f;
        leftArm.xRot = -0.85f + Mth.cos(limbSwing * 0.6662f) * 0.5f * limbSwingAmount - idle;
        leftArm.yRot = -0.25f;
        // keep the staff upright in the world no matter how the arm swings
        staff.xRot = -rightArm.xRot;
        staff.yRot = -rightArm.yRot;

        rightBoot.xRot = Mth.cos(limbSwing * 0.6662f) * 1.2f * limbSwingAmount;
        leftBoot.xRot = Mth.cos(limbSwing * 0.6662f + (float) Math.PI) * 1.2f * limbSwingAmount;

        orb.y = -4f + Mth.sin(ageInTicks * 0.12f) * 1.5f;
        orb.x = -9f + Mth.cos(ageInTicks * 0.07f) * 1.0f;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
