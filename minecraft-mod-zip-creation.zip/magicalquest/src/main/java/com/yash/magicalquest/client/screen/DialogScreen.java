package com.yash.magicalquest.client.screen;

import com.yash.magicalquest.client.ClientText;
import com.yash.magicalquest.network.AcceptQuestPacket;
import com.yash.magicalquest.network.Net;
import com.yash.magicalquest.network.OpenDialogPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/** Visual-novel style story dialogue with the Village Mage. */
public class DialogScreen extends Screen {
    private final OpenDialogPacket data;
    private int page;
    private float chars;
    private int ticks;
    private Button accept;
    private Button decline;

    public DialogScreen(OpenDialogPacket data) {
        super(Component.literal(data.speaker()));
        this.data = data;
    }

    private boolean lastPage() {
        return page >= data.pages().size() - 1;
    }

    private String text() {
        return data.pages().get(page);
    }

    private int panelTop() {
        return height - 138;
    }

    @Override
    protected void init() {
        int right = width - 42;
        int by = panelTop() + 138 - 34;
        accept = addRenderableWidget(Button.builder(Component.literal("Accept Quest"), b -> {
            Net.toServer(new AcceptQuestPacket(data.questId()));
            onClose();
        }).bounds(right - 210, by, 100, 20).build());
        decline = addRenderableWidget(Button.builder(Component.literal("Not now"), b -> onClose())
                .bounds(right - 100, by, 100, 20).build());
        updateButtons();
    }

    private void updateButtons() {
        boolean show = data.mode() == 1 && lastPage() && chars >= text().length();
        accept.visible = show;
        decline.visible = show;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void tick() {
        ticks++;
        chars += 1.8f;
        updateButtons();
    }

    private void advance() {
        if (chars < text().length()) {
            chars = text().length();
            return;
        }
        if (!lastPage()) {
            page++;
            chars = 0;
        } else if (data.mode() == 0) {
            onClose();
        }
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_SPACE || key == GLFW.GLFW_KEY_ENTER) {
            advance();
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) {
            return true;
        }
        advance();
        return true;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        g.fillGradient(0, panelTop() - 40, width, height, 0x00000000, 0xAA000000);
        int x0 = 30;
        int x1 = width - 30;
        int top = panelTop();
        int bottom = height - 6;
        g.fill(x0 - 1, top - 1, x1 + 1, bottom + 1, 0xFFB48CFF);
        g.fill(x0, top, x1, bottom, 0xEE100818);
        g.fillGradient(x0, top, x1, top + 20, 0x449B6BFF, 0x00100818);

        // portrait
        Entity e = Minecraft.getInstance().level == null ? null : Minecraft.getInstance().level.getEntity(data.entityId());
        int px = x0 + 56;
        if (e instanceof LivingEntity living) {
            InventoryScreen.renderEntityInInventoryFollowsMouse(g, px, bottom - 14, 50, px - mx, bottom - 80 - my, living);
        }

        // name plate
        int nameW = font.width(data.speaker()) + 20;
        g.fill(x0 + 100, top - 12, x0 + 100 + nameW, top + 6, 0xFFB48CFF);
        g.fill(x0 + 101, top - 11, x0 + 99 + nameW, top + 5, 0xFF2A1646);
        g.drawString(font, data.speaker(), x0 + 110, top - 7, 0xFFFFE9A8, true);

        // text
        int tx = x0 + 112;
        int tw = x1 - tx - 14;
        List<String> lines = ClientText.wrap(font, text(), tw);
        ClientText.drawTyped(g, font, lines, tx, top + 14, 11, 0xFFF2EAFF, (int) chars, false, 0);

        if (chars >= text().length() && !(data.mode() == 1 && lastPage())) {
            String hint = lastPage() ? "[Click to close]" : "[Click to continue]";
            int c = (ticks / 10) % 2 == 0 ? 0xFFB9A6E8 : 0xFF6E5E9E;
            g.drawString(font, hint, x1 - 14 - font.width(hint), bottom - 14, c, false);
        }
        super.render(g, mx, my, pt);
    }
}
