package com.yash.magicalquest.client.screen;

import com.yash.magicalquest.client.ClientText;
import com.yash.magicalquest.magic.PlayerMagic;
import com.yash.magicalquest.network.AbandonQuestPacket;
import com.yash.magicalquest.network.Net;
import com.yash.magicalquest.quest.Quest;
import com.yash.magicalquest.quest.QuestManager;
import com.yash.magicalquest.skill.Skill;
import com.yash.magicalquest.skill.Skills;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

/** Overview of element, mana, skills and the active quest. */
public class StatusScreen extends Screen {
    private static final int W = 340;
    private static final int H = 238;
    private Button abandon;

    public StatusScreen() {
        super(Component.literal("Status"));
    }

    @Override
    protected void init() {
        int px = (width - W) / 2;
        int py = (height - H) / 2;
        abandon = addRenderableWidget(Button.builder(Component.literal("Abandon quest"), b -> {
            Net.toServer(new AbandonQuestPacket());
            PlayerMagic m = PlayerMagic.get(Minecraft.getInstance().player);
            m.activeQuest = "";
            m.progress = 0;
        }).bounds(px + W - 112, py + H - 28, 100, 18).build());
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        Minecraft mc = Minecraft.getInstance();
        PlayerMagic m = PlayerMagic.get(mc.player);
        int px = (width - W) / 2;
        int py = (height - H) / 2;
        int col = m.element.argb();

        g.fill(px - 2, py - 2, px + W + 2, py + H + 2, col);
        g.fill(px, py, px + W, py + H, 0xF0140A24);
        g.fillGradient(px, py, px + W, py + 30, 0x55000000 | m.element.color, 0x00000000);

        g.drawString(font, "Magical Quest", px + 12, py + 9, 0xFFFFFFFF, true);
        String el = m.element.displayName + " Mage";
        g.drawString(font, el, px + W - 12 - font.width(el), py + 9, col, true);
        g.drawString(font, "Mana " + (int) m.mana + "/" + (int) m.maxMana(), px + 12, py + 24, 0xFFBDE9FF, true);
        String done = "Quests completed: " + m.completedQuests.size();
        g.drawString(font, done, px + W - 12 - font.width(done), py + 24, 0xFFE6E6E6, true);

        // skills grid
        List<Skill> all = Skills.of(m.element);
        Skill hoverSkill = null;
        for (int i = 0; i < all.size(); i++) {
            Skill s = all.get(i);
            int col2 = i / 5;
            int row = i % 5;
            int sx = px + 12 + col2 * 163;
            int sy = py + 44 + row * 23;
            boolean unlocked = m.unlocked.contains(s.id);
            boolean selected = s.id.equals(m.selected);
            g.fill(sx - 1, sy - 1, sx + 20, sy + 20, selected ? 0xFFFFD25A : unlocked ? col : 0xFF3A3050);
            g.fill(sx, sy, sx + 19, sy + 19, 0xFF10091C);
            g.blit(s.iconTexture(), sx + 1, sy + 1, 17, 17, 0f, 0f, 16, 16, 16, 16);
            if (!unlocked) {
                g.fill(sx, sy, sx + 19, sy + 19, 0xAA000000);
            }
            g.drawString(font, s.name, sx + 26, sy + 1, unlocked ? 0xFFFFFFFF : 0xFF77708A, true);
            String sub = unlocked ? (selected ? "Selected" : "Unlocked") : "Locked - quest " + i;
            g.drawString(font, sub, sx + 26, sy + 11, unlocked ? 0xFF8FD6A0 : 0xFF5E5878, false);
            if (mx >= sx && mx < sx + 160 && my >= sy && my < sy + 20) {
                hoverSkill = s;
            }
        }

        // active quest
        int qy = py + 166;
        g.fill(px + 10, qy - 4, px + W - 10, qy - 3, 0x55FFFFFF);
        Quest q = QuestManager.active(m);
        if (q != null) {
            int prog = QuestManager.progress(mc.player, m, q);
            g.drawString(font, "Active quest: " + q.title, px + 12, qy, 0xFFFFD25A, true);
            g.drawString(font, q.objective(prog), px + 12, qy + 12, prog >= q.count ? 0xFF7CFF8A : 0xFFE6E6E6, true);
            if (prog >= q.count) {
                g.drawString(font, "Return to a Village Mage to claim your reward.", px + 12, qy + 24, 0xFF7CFF8A, true);
            }
        } else {
            g.drawString(font, "No active quest.", px + 12, qy, 0xFFE6E6E6, true);
            Quest next = QuestManager.next(m);
            String hint = next != null ? "Speak with a Village Mage for your next quest." : "You have completed every quest for now.";
            g.drawString(font, hint, px + 12, qy + 12, 0xFF9C94B8, true);
        }
        abandon.visible = q != null;

        g.drawString(font, "[R] hold: wheel   [Z]: cast   [K]: status", px + 12, py + H - 14, 0xFF6E6690, false);
        super.render(g, mx, my, pt);

        if (hoverSkill != null) {
            String tip = hoverSkill.description + "  (Mana " + hoverSkill.manaCost + ", CD "
                    + String.format("%.0f", hoverSkill.cooldown / 20f) + "s)";
            g.renderTooltip(font, ClientText.wrap(font, tip, 200).stream()
                    .map(s -> Component.literal(s).getVisualOrderText()).toList(), mx, my);
        }
    }
}
