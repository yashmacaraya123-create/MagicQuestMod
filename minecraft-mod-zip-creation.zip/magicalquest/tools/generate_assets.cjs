#!/usr/bin/env node
/**
 * Procedural pixel-art generator for Magical Quest.
 * Run with:  node tools/generate_assets.js
 * Writes PNGs into src/main/resources/assets/magicalquest/textures/
 * No dependencies (uses Node's built-in zlib).
 */
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const OUT = path.join(__dirname, '..', 'src', 'main', 'resources', 'assets', 'magicalquest', 'textures');

// ------------------------------------------------------------------ PNG writer
const CRC = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();
function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC[(c ^ buf[i]) & 255] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}
function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length);
  const td = Buffer.concat([Buffer.from(type), data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(td));
  return Buffer.concat([len, td, crc]);
}
function encodePNG(w, h, rgba) {
  const raw = Buffer.alloc((w * 4 + 1) * h);
  for (let y = 0; y < h; y++) {
    raw[y * (w * 4 + 1)] = 0;
    rgba.copy(raw, y * (w * 4 + 1) + 1, y * w * 4, (y + 1) * w * 4);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0);
  ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8; ihdr[9] = 6; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  return Buffer.concat([
    Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    chunk('IHDR', ihdr),
    chunk('IDAT', zlib.deflateSync(raw, { level: 9 })),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

class Img {
  constructor(w, h) { this.w = w; this.h = h; this.d = Buffer.alloc(w * h * 4); }
  set(x, y, c, a = 255) {
    x = Math.floor(x); y = Math.floor(y);
    if (x < 0 || y < 0 || x >= this.w || y >= this.h || c === null || c === undefined) return;
    const i = (y * this.w + x) * 4;
    this.d[i] = (c >> 16) & 255; this.d[i + 1] = (c >> 8) & 255; this.d[i + 2] = c & 255; this.d[i + 3] = a;
  }
  alpha(x, y) { return this.d[(y * this.w + x) * 4 + 3]; }
  save(file) {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, encodePNG(this.w, this.h, this.d));
  }
}

// ------------------------------------------------------------------- helpers
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
function shade(c, f) {
  const r = clamp(Math.round(((c >> 16) & 255) * f), 0, 255);
  const g = clamp(Math.round(((c >> 8) & 255) * f), 0, 255);
  const b = clamp(Math.round((c & 255) * f), 0, 255);
  return (r << 16) | (g << 8) | b;
}
function mix(a, b, t) {
  const f = (s) => Math.round(((a >> s) & 255) * (1 - t) + ((b >> s) & 255) * t);
  return (f(16) << 16) | (f(8) << 8) | f(0);
}
const dist = (x, y, cx, cy) => Math.hypot(x - cx, y - cy);
function segDist(x, y, x1, y1, x2, y2) {
  const dx = x2 - x1, dy = y2 - y1;
  const t = clamp(((x - x1) * dx + (y - y1) * dy) / (dx * dx + dy * dy), 0, 1);
  return { d: Math.hypot(x - (x1 + t * dx), y - (y1 + t * dy)), t };
}
function inPoly(x, y, pts) {
  let inside = false;
  for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
    const [xi, yi] = pts[i], [xj, yj] = pts[j];
    if ((yi > y) !== (yj > y) && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}

const PAL = {
  fire:      { dark: 0x8a1c0a, mid: 0xff5a1f, light: 0xffc247 },
  water:     { dark: 0x103f8f, mid: 0x2f8cff, light: 0xa6e3ff },
  earth:     { dark: 0x4a3418, mid: 0xb08a4e, light: 0xe3c88f },
  wind:      { dark: 0x2c8f78, mid: 0x7fe3c4, light: 0xeafff7 },
  light:     { dark: 0xc9a63a, mid: 0xfff1a8, light: 0xffffff },
  lightning: { dark: 0xb07a00, mid: 0xffd21f, light: 0xfffbb0 },
  dark:      { dark: 0x2a0f45, mid: 0x8a3fd1, light: 0xe0b3ff },
};

// ------------------------------------------------------------- skill icons
const ICONS = {
  ORB: (x, y) => {
    if (dist(x, y, 9.8, 6.2, 0) <= 4.7) return true;
    const s = segDist(x, y, 1.6, 14.4, 7, 9);
    return s.d <= 0.5 + 1.5 * s.t;
  },
  DASH: (x, y) => {
    for (const c of [0, 4, 8]) {
      const t = x - (c + 5.5 - Math.abs(y - 8) * 0.85);
      if (t > -1.5 && t <= 0.8 && Math.abs(y - 8) <= 5.6) return true;
    }
    return false;
  },
  NOVA: (x, y) => {
    const r = dist(x, y, 8, 8), a = Math.atan2(y - 8, x - 8);
    return r <= 2.3 + 5.4 * Math.pow(Math.abs(Math.cos(2 * a)), 6) || r <= 2.2 + 2.8 * Math.pow(Math.abs(Math.sin(2 * a)), 6);
  },
  BEAM: (x, y) => {
    const w = 0.6 + (x / 16) * 1.7;
    if (Math.abs(x + y - 16) / 1.414 <= w && x >= 1 && x <= 14) return true;
    return dist(x, y, 12.6, 3.4) <= 2.8;
  },
  SHIELD: (x, y) => {
    if (y < 1.2 || y > 15) return false;
    const hw = y < 9 ? 5.9 : Math.max(0, 5.9 - (y - 9) * 0.98);
    return Math.abs(x - 8) <= hw;
  },
  HEART: (x, y) => {
    const px = (x - 8) / 6.4, py = -(y - 8.4) / 6.2;
    return Math.pow(px * px + py * py - 1, 3) - px * px * py * py * py <= 0;
  },
  SPIKE: (x, y) => {
    if (y >= 13.4 && x >= 1 && x <= 15) return true;
    for (const [cx, y0, hb] of [[8, 1, 3.8], [3.4, 6, 2.5], [12.6, 7, 2.5]]) {
      if (y >= y0 && y <= 14 && Math.abs(x - cx) <= (hb * (y - y0)) / (14 - y0)) return true;
    }
    return false;
  },
  WARP: (x, y) => {
    const r = dist(x, y, 8, 8), a = Math.atan2(y - 8, x - 8);
    const gapA = Math.abs(Math.atan2(Math.sin(a - 0.6), Math.cos(a - 0.6))) < 0.38;
    const gapB = Math.abs(Math.atan2(Math.sin(a - 0.6 - Math.PI), Math.cos(a - 0.6 - Math.PI))) < 0.38;
    return (r >= 4.4 && r <= 6.8 && !gapA && !gapB) || r <= 2.1;
  },
  VORTEX: (x, y) => {
    const r = dist(x, y, 8, 8);
    if (r < 0.8 || r > 7.4) return false;
    const a = Math.atan2(y - 8, x - 8);
    const s = r / 2.7 - (a + Math.PI) / (2 * Math.PI);
    return s - Math.floor(s) < 0.46;
  },
  SUN: (x, y) => {
    const r = dist(x, y, 8, 8), a = Math.atan2(y - 8, x - 8);
    return r <= 3.8 || (r >= 5.1 && r <= 7.8 && Math.abs(Math.cos(4 * a)) > 0.9);
  },
};
const ICON_ACCENT = {
  SHIELD: (x, y) => (Math.abs(x - 8) < 0.9 && y > 3 && y < 12) || (Math.abs(y - 6) < 0.9 && Math.abs(x - 8) <= 4),
  ORB: (x, y) => dist(x, y, 8.4, 4.9) <= 1.3,
  HEART: (x, y) => dist(x, y, 5.6, 5.4) <= 1.0,
  SUN: (x, y) => dist(x, y, 7, 7) <= 1.6,
  WARP: (x, y) => dist(x, y, 8, 8) <= 0.9,
};

const THIN = new Set(['DASH', 'VORTEX', 'WARP', 'NOVA']);

function drawSkillIcon(element, iconName) {
  const p = PAL[element];
  const mask = ICONS[iconName];
  const accent = ICON_ACCENT[iconName];
  const img = new Img(16, 16);
  const m = [];
  for (let y = 0; y < 16; y++) {
    m[y] = [];
    for (let x = 0; x < 16; x++) m[y][x] = !!mask(x + 0.5, y + 0.5);
  }
  const at = (x, y) => (x >= 0 && y >= 0 && x < 16 && y < 16 ? m[y][x] : false);
  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
      if (m[y][x]) {
        const edge = !at(x - 1, y) || !at(x + 1, y) || !at(x, y - 1) || !at(x, y + 1);
        if (THIN.has(iconName)) {
          // thin strokes: bright top-left edge, solid mid body, darker bottom-right edge
          if (!at(x - 1, y) || !at(x, y - 1)) img.set(x, y, p.light);
          else if (!at(x + 1, y) || !at(x, y + 1)) img.set(x, y, shade(p.mid, 0.72));
          else img.set(x, y, p.mid);
          continue;
        }
        if (edge) { img.set(x, y, shade(p.dark, 0.75)); continue; }
        const t = (x + y) / 30;
        let c = t < 0.4 ? p.light : t < 0.7 ? p.mid : shade(p.mid, 0.78);
        if (accent && accent(x + 0.5, y + 0.5)) c = 0xffffff;
        img.set(x, y, c);
      } else {
        let near = false;
        for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) if (at(x + dx, y + dy)) near = true;
        if (near) img.set(x, y, p.mid, 55);
      }
    }
  }
  return img;
}

// ------------------------------------------------------------------- items
function drawShard(p) {
  const img = new Img(16, 16);
  const pts = [[8, 0.5], [12.4, 5], [10.6, 15.2], [5, 10.2], [3.8, 5]];
  for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
    const px = x + 0.5, py = y + 0.5;
    if (!inPoly(px, py, pts)) continue;
    const inner = inPoly(px - 0.0, py, pts) && inPoly(px + 1, py, pts) && inPoly(px - 1, py, pts) && inPoly(px, py + 1, pts) && inPoly(px, py - 1, pts);
    let c = px < 7.4 + py * 0.16 ? p.light : px < 9.2 + py * 0.1 ? p.mid : shade(p.mid, 0.72);
    if (!inner) c = shade(p.dark, 0.8);
    img.set(x, y, c);
  }
  img.set(6, 4, 0xffffff); img.set(7, 3, 0xffffff); img.set(6, 5, 0xe8f7ff);
  return img;
}

function drawCrystal() {
  const img = new Img(16, 16);
  const pts = [[8, 0.4], [14.6, 5.6], [8, 15.6], [1.4, 5.6]];
  for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
    const px = x + 0.5, py = y + 0.5;
    if (!inPoly(px, py, pts)) continue;
    const inner = inPoly(px + 1, py, pts) && inPoly(px - 1, py, pts) && inPoly(px, py + 1, pts) && inPoly(px, py - 1, pts);
    let c;
    if (py < 5.6) c = px < 5.5 ? 0xe9dcff : px < 10.5 ? 0xb9f3ff : 0x9d7bff;
    else c = px < 8 ? 0x7e5be8 : 0x4a2fa8;
    if (py > 5.2 && py < 6.4) c = mix(c, 0xffffff, 0.35);
    if (!inner) c = 0x2a1668;
    img.set(x, y, c);
  }
  for (const [sx, sy] of [[1, 2], [14, 2], [13, 13], [2, 12]]) {
    img.set(sx, sy, 0xffffff); img.set(sx - 1, sy, 0xbfa6ff, 150); img.set(sx + 1, sy, 0xbfa6ff, 150);
    img.set(sx, sy - 1, 0xbfa6ff, 150); img.set(sx, sy + 1, 0xbfa6ff, 150);
  }
  img.set(6, 3, 0xffffff); img.set(7, 2, 0xffffff);
  return img;
}

function drawPotion() {
  const img = new Img(16, 16);
  const GLASS = 0xcfe8ff, OUTL = 0x24324f;
  // cork
  for (let y = 1; y <= 2; y++) for (let x = 6; x <= 9; x++) img.set(x, y, y === 1 ? 0xb98a52 : 0x8a6234);
  // neck
  for (let y = 3; y <= 5; y++) { img.set(6, y, OUTL); img.set(9, y, OUTL); img.set(7, y, 0xe3f2ff, 200); img.set(8, y, GLASS, 200); }
  // body
  for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
    const d = dist(x + 0.5, y + 0.5, 8, 10.4);
    if (d <= 5.4 && y >= 5) {
      if (d > 4.5) img.set(x, y, OUTL);
      else if (y >= 8) {
        const t = clamp((x + y - 11) / 14, 0, 1);
        img.set(x, y, t < 0.35 ? 0x7fd0ff : t < 0.65 ? 0x2f8cff : 0x1d56c8);
      } else img.set(x, y, GLASS, 90);
    }
  }
  img.set(6, 9, 0xffffff); img.set(6, 10, 0xffffff); img.set(7, 8, 0xe3f2ff);
  img.set(10, 12, 0x9ff3ff); img.set(9, 11, 0xffffff);
  return img;
}

function drawStaff() {
  const img = new Img(16, 16);
  for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
    const px = x + 0.5, py = y + 0.5;
    const s = segDist(px, py, 1.6, 14.6, 10.2, 6.0);
    if (s.d <= 1.05) {
      let c = s.d > 0.65 ? 0x3a2414 : (Math.floor(s.t * 8) % 2 === 0 ? 0x8c6439 : 0x6b4a2b);
      if (Math.abs(s.t - 0.35) < 0.04 || Math.abs(s.t - 0.62) < 0.04) c = 0xe6c34a;
      img.set(x, y, c);
    }
  }
  // gem holder (gold crescent) + gem
  for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
    const px = x + 0.5, py = y + 0.5;
    const d = dist(px, py, 11.4, 4.6);
    const a = Math.atan2(py - 4.6, px - 11.4);
    if (d >= 2.9 && d <= 4.0 && (a > 0.4 || a < -2.6)) img.set(x, y, d > 3.6 ? 0xa8841f : 0xe6c34a);
    if (d <= 2.7) img.set(x, y, d > 2.0 ? 0x2b9ab8 : d > 1.0 ? 0x7ff3ff : 0xffffff);
  }
  img.set(12, 3, 0xffffff);
  return img;
}

function drawCharm(p) {
  const img = new Img(16, 16);
  const GOLD = 0xe6c34a, GOLD2 = 0xa8841f;
  // chain ring
  for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
    const d = dist(x + 0.5, y + 0.5, 8, 4.4);
    if (d >= 2.6 && d <= 3.9 && y < 8) img.set(x, y, d > 3.4 ? GOLD2 : GOLD);
  }
  // pendant frame + gem
  const frame = [[8, 5.0], [13.2, 10.4], [8, 16], [2.8, 10.4]];
  const gem = [[8, 6.6], [11.6, 10.4], [8, 14.4], [4.4, 10.4]];
  for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
    const px = x + 0.5, py = y + 0.5;
    if (inPoly(px, py, frame)) img.set(x, y, py < 9 ? GOLD : GOLD2);
    if (inPoly(px, py, gem)) {
      let c;
      if (py < 10.4) c = px < 8 ? p.light : p.mid;
      else c = px < 8 ? shade(p.mid, 0.85) : shade(p.mid, 0.6);
      img.set(x, y, c);
    }
  }
  img.set(6, 9, 0xffffff); img.set(7, 8, 0xffffff);
  return img;
}

function drawSparkleTemplate() { return null; }

// ------------------------------------------------------------- mage texture
function box(img, u, v, w, h, d, painter) {
  const faces = {
    top: [u + d, v, w, d],
    bottom: [u + d + w, v, w, d],
    right: [u, v + d, d, h],
    front: [u + d, v + d, w, h],
    left: [u + d + w, v + d, d, h],
    back: [u + 2 * d + w, v + d, w, h],
  };
  for (const [name, [fx, fy, fw, fh]] of Object.entries(faces)) {
    for (let y = 0; y < fh; y++) for (let x = 0; x < fw; x++) {
      const c = painter(name, x, y, fw, fh);
      if (c !== null && c !== undefined) img.set(fx + x, fy + y, c);
    }
  }
}

function drawMage() {
  const img = new Img(128, 64);
  const SK = 0xe5b48c, SK2 = 0xc99468, HAIR = 0xf0f0f8, HAIR2 = 0xc3c3d6;
  const IND = 0x3d2b7c, IND2 = 0x52399f, IND3 = 0x2b1d5c, GOLD = 0xe6c34a, GOLD2 = 0xa8841f, EYE = 0x6ff7ff;
  const noise = (x, y, s = 7) => ((x * 73 + y * 151 + s * 31) % 5 === 0 ? 0.92 : 1);

  // head 8x8x8
  box(img, 0, 0, 8, 8, 8, (f, x, y, w, h) => {
    if (f === 'top') return shade(HAIR, noise(x, y));
    if (f === 'bottom') return SK2;
    if (f === 'back') return shade(y > 5 ? HAIR2 : HAIR, noise(x, y, 3));
    if (f === 'front') {
      if (y < 2) return shade(HAIR, noise(x, y));
      if (y === 2 && (x === 0 || x === 7)) return HAIR;
      if (y === 2 && ((x >= 1 && x <= 2) || (x >= 5 && x <= 6))) return HAIR2; // brows
      if (y === 3 && ((x >= 1 && x <= 2) || (x >= 5 && x <= 6))) return x === 1 || x === 5 ? 0x2b2b44 : EYE;
      if (y >= 5) {
        const ok = y === 5 ? x >= 1 && x <= 6 : y === 6 ? true : x >= 1 && x <= 6;
        if (ok) return y === 5 && (x === 3 || x === 4) ? SK2 : shade(HAIR, noise(x, y, 5));
      }
      return SK;
    }
    // right / left sides
    const frontEdge = f === 'right' ? w - 1 - x : x; // 0 = nearest the face
    if (y < 3 || (y < 5 && frontEdge >= 3)) return shade(HAIR, noise(x, y, 2));
    if (y >= 5 && frontEdge <= 2) return HAIR;
    if (frontEdge >= 4 && y >= 5) return HAIR2;
    return SK;
  });
  // nose 2x3x2 at (40,16)
  box(img, 40, 16, 2, 3, 2, (f) => (f === 'top' ? SK : SK2));
  // hat brim 14x1x14
  box(img, 32, 0, 14, 1, 14, (f, x, y, w, h) => {
    if (f === 'top') return x === 0 || y === 0 || x === w - 1 || y === h - 1 ? GOLD : ((x + y) % 7 === 0 ? IND3 : IND2);
    if (f === 'bottom') return IND3;
    return GOLD;
  });
  // hat base 8x4x8
  box(img, 88, 0, 8, 4, 8, (f, x, y) => {
    if (f === 'top') return IND2;
    if (f === 'bottom') return IND3;
    if (y === 3) return GOLD; // band
    if (y === 2) return IND3;
    return (x + y) % 4 === 0 ? IND2 : IND;
  });
  // hat mid 6x4x6
  box(img, 0, 16, 6, 4, 6, (f, x, y) => {
    if (f === 'top') return IND;
    if (f === 'bottom') return IND3;
    if (f === 'front' && ((x === 2 && y === 1) || (x === 3 && y === 2))) return GOLD;
    return y < 2 ? IND2 : IND;
  });
  // hat tip 3x3x3
  box(img, 24, 16, 3, 3, 3, (f, x, y) => (f === 'top' ? GOLD : mix(0x7a5de0, IND2, y / 3)));
  // body 8x12x4
  box(img, 0, 28, 8, 12, 4, (f, x, y, w, h) => {
    if (f === 'top') return IND2;
    if (f === 'bottom') return IND3;
    if (f === 'front') {
      if (y >= 7 && y <= 8) return x === 3 || x === 4 ? GOLD : GOLD2; // belt + buckle
      if (x === 3 || x === 4) return GOLD; // central strip
      if (y < 2) return IND2;
      return x === 0 || x === 7 ? IND3 : IND;
    }
    if (f === 'back') return y < 2 ? IND : IND3;
    return y < 2 ? IND2 : IND;
  });
  // robe 10x14x6
  box(img, 24, 28, 10, 14, 6, (f, x, y, w, h) => {
    if (f === 'top' || f === 'bottom') return IND3;
    if (y >= h - 2) return y === h - 1 ? GOLD2 : GOLD; // gold hem
    if (y === h - 3) return IND3;
    if (f === 'front') {
      if (x === 4 || x === 5) return mix(GOLD, IND, 0.35);
      if ((x === 2 && y === 6) || (x === 7 && y === 8) || (x === 1 && y === 10)) return GOLD2;
      return x % 3 === 0 ? IND3 : IND;
    }
    return x % 3 === 0 ? 0x231650 : IND3;
  });
  // cape 8x14x1
  box(img, 0, 46, 8, 14, 1, (f, x, y, w, h) => {
    if (f === 'back') {
      const star = (x === 4 && y >= 5 && y <= 8) || (y === 6 && x >= 2 && x <= 6) || (x === 3 && y === 5) || (x === 5 && y === 7);
      if (star) return GOLD;
      if (x === 0 || x === w - 1 || y === h - 1) return 0x3a2877;
      return (x + y) % 5 === 0 ? 0x251850 : 0x2a1b57;
    }
    return 0x1f1340;
  });
  // arms 4x8x4 (right at 56,28 / left at 72,28)
  const arm = (f, x, y) => {
    if (f === 'top') return IND2;
    if (f === 'bottom') return SK;
    if (y === 7) return SK;
    if (y === 6) return GOLD;
    return y === 0 ? IND2 : (x + y) % 3 === 0 ? IND3 : IND;
  };
  box(img, 56, 28, 4, 8, 4, arm);
  box(img, 72, 28, 4, 8, 4, arm);
  // boots 4x2x5
  box(img, 88, 28, 4, 2, 5, (f, x, y) => (f === 'bottom' ? 0x2a1a0e : y === 1 ? 0x3a2414 : 0x5a3a22));
  // orb / gem 3x3x3
  box(img, 106, 28, 3, 3, 3, (f, x, y) => (x === 1 && y === 1 ? 0xffffff : mix(EYE, 0x2b9ab8, (x + y) / 6)));
  // staff pole 1x26x1
  box(img, 106, 34, 1, 26, 1, (f, x, y) => (y % 4 === 0 ? 0x8c6439 : y % 7 === 3 ? GOLD : 0x6b4a2b));
  return img;
}

// ------------------------------------------------------------------- main
function main() {
  // skill icons: 7 elements x 10 icons
  for (const el of Object.keys(PAL)) {
    for (const icon of Object.keys(ICONS)) {
      drawSkillIcon(el, icon).save(path.join(OUT, 'gui', 'skill', `${el}_${icon.toLowerCase()}.png`));
    }
  }
  // items
  const item = (name, img) => img.save(path.join(OUT, 'item', `${name}.png`));
  item('mana_shard', drawShard({ light: 0xa6e3ff, mid: 0x3aa0ff, dark: 0x1c4fa8 }));
  item('rebirth_crystal', drawCrystal());
  item('mana_potion', drawPotion());
  item('mage_staff', drawStaff());
  for (const el of Object.keys(PAL)) item(`charm_${el}`, drawCharm(PAL[el]));
  // entity
  drawMage().save(path.join(OUT, 'entity', 'mage.png'));
  console.log('Textures generated in', OUT);
}

if (require.main === module) main();

module.exports = { Img, PAL, ICONS, drawSkillIcon, drawShard, drawCrystal, drawPotion, drawStaff, drawCharm, drawMage };
