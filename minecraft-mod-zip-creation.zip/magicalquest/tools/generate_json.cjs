#!/usr/bin/env node
/** Generates lang, item models and recipes. Run: node tools/generate_json.cjs */
const fs = require('fs');
const path = require('path');
const RES = path.join(__dirname, '..', 'src', 'main', 'resources');
const ASSETS = path.join(RES, 'assets', 'magicalquest');
const DATA = path.join(RES, 'data', 'magicalquest');
const write = (file, obj) => {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(obj, null, 2) + '\n');
};
const ELEMENTS = ['fire', 'water', 'earth', 'wind', 'light', 'lightning', 'dark'];
const cap = (s) => s[0].toUpperCase() + s.slice(1);

// ---- lang
const lang = {
  'itemGroup.magicalquest': 'Magical Quest',
  'item.magicalquest.rebirth_crystal': 'Rebirth Crystal',
  'item.magicalquest.mana_potion': 'Mana Potion',
  'item.magicalquest.mana_shard': 'Mana Shard',
  'item.magicalquest.mage_staff': 'Mage Staff',
  'item.magicalquest.mage_spawn_egg': 'Village Mage Spawn Egg',
  'entity.magicalquest.mage': 'Village Mage',
  'entity.magicalquest.magic_projectile': 'Magic Bolt',
  'key.categories.magicalquest': 'Magical Quest',
  'key.magicalquest.wheel': 'Skill Wheel (hold)',
  'key.magicalquest.cast': 'Cast Selected Skill',
  'key.magicalquest.status': 'Status & Quests',
};
for (const e of ELEMENTS) lang[`item.magicalquest.charm_${e}`] = `${cap(e)} Charm`;
write(path.join(ASSETS, 'lang', 'en_us.json'), lang);

// ---- item models
const generated = (tex, parent = 'minecraft:item/generated') => ({ parent, textures: { layer0: `magicalquest:item/${tex}` } });
write(path.join(ASSETS, 'models', 'item', 'rebirth_crystal.json'), generated('rebirth_crystal'));
write(path.join(ASSETS, 'models', 'item', 'mana_potion.json'), generated('mana_potion'));
write(path.join(ASSETS, 'models', 'item', 'mana_shard.json'), generated('mana_shard'));
write(path.join(ASSETS, 'models', 'item', 'mage_staff.json'), generated('mage_staff', 'minecraft:item/handheld'));
write(path.join(ASSETS, 'models', 'item', 'mage_spawn_egg.json'), { parent: 'minecraft:item/template_spawn_egg' });
for (const e of ELEMENTS) write(path.join(ASSETS, 'models', 'item', `charm_${e}.json`), generated(`charm_${e}`));

// ---- recipes
const r = (name, obj) => write(path.join(DATA, 'recipes', `${name}.json`), obj);
r('mana_shard', {
  type: 'minecraft:crafting_shapeless', category: 'misc',
  ingredients: [{ item: 'minecraft:amethyst_shard' }, { item: 'minecraft:lapis_lazuli' }, { item: 'minecraft:lapis_lazuli' }],
  result: { item: 'magicalquest:mana_shard', count: 2 },
});
r('mana_potion', {
  type: 'minecraft:crafting_shapeless', category: 'misc',
  ingredients: [{ item: 'magicalquest:mana_shard' }, { item: 'magicalquest:mana_shard' }, { item: 'minecraft:glass_bottle' }],
  result: { item: 'magicalquest:mana_potion', count: 1 },
});
r('mage_staff', {
  type: 'minecraft:crafting_shaped', category: 'equipment',
  pattern: ['  A', ' M ', 'S  '],
  key: { A: { item: 'minecraft:amethyst_shard' }, M: { item: 'magicalquest:mana_shard' }, S: { item: 'minecraft:stick' } },
  result: { item: 'magicalquest:mage_staff', count: 1 },
});
r('rebirth_crystal', {
  type: 'minecraft:crafting_shaped', category: 'misc',
  pattern: ['ADA', 'DPD', 'ADA'],
  key: { A: { item: 'minecraft:amethyst_shard' }, D: { item: 'minecraft:diamond' }, P: { item: 'minecraft:ender_pearl' } },
  result: { item: 'magicalquest:rebirth_crystal', count: 1 },
});
console.log('JSON resources generated');
