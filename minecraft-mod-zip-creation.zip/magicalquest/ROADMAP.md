# Magical Quest Roadmap

## Phase 1 + 2 (base) - DONE in v0.1.0
- [x] Reincarnation intro and element choice on first join (7 elements)
- [x] Rebirth Crystal to change element later
- [x] Mana system (HUD bar, regeneration, potions, charms)
- [x] 70 skills (10 per element) with a skill wheel (`R`) and a cast key (`Z`)
- [x] Village Mage NPC with an original model and texture, spawns in villages
- [x] Story dialogue screen (visual-novel style) and quest engine
- [x] 69 quests: hunt/boss, mine, gather, build, craft, explore
- [x] Rewards: skills, Mage Staff, Elemental Charms, Mana items, XP
- [x] Per-element passives, status screen (`K`), quest tracker HUD
- [x] GitHub Actions build

## Phase 3 - The Guide ("Navi")
- A floating spirit companion you can summon
- Question menu: "Where is the Mage?", "What does my element do?", "What is my next quest?", "Tell me about this world"...
- Answers react to your element, quest progress and nearby structures, in an anime-narrator voice

## Phase 4 - The World
### New biomes
- **Ember Wastes** (Fire), **Starlit Meadow** (Light), **Stormspire Highlands** (Lightning), **Glimmering Depths** (Water), **Whisperwood** (Dark)

### Structures
- Mage Tower, Spirit Shrines (one per element), Boss arenas, Ruined Temple of the Goddess, Hidden elemental dungeons

### Bosses
Each boss drops a unique relic and counts as a "boss quest" (replacing some of the vanilla-boss quests used in v0.1.0).

| Boss | Element | Idea |
|---|---|---|
| **Pyrrhos, the Ember Tyrant** | Fire | Giant magma knight; rains meteors in phase 2 |
| **Maren, the Tide Empress** | Water | Floods the arena, summons whirlpools and ice spears |
| **Gorgrim, the Mountain Colossus** | Earth | Slow but huge; rock slams and falling boulders |
| **Zephyra, the Sky Serpent** | Wind | Flies in circles, tornado attacks, fast dive bombs |
| **Seraphiel, the Fallen Dawn** | Light | Angelic swordmaster with beams of light and a healing barrier |
| **Raijin-Kor, the Thunder Beast** | Lightning | Chain lightning, teleporting strikes, charges up for a storm finale |
| **Nyx-Vael, the Shadow Sovereign** | Dark | Teleports, drains life, plunges the arena into darkness |
| **The Corrupted Mage** | None | Mid-game dungeon boss: a former Village Mage gone mad (story twist) |
| **The Demon Lord Vorathul** | All | Final boss of the main story; uses a skill from every element |
| **Twin Guardians of the Goddess** | None | Optional hard duo fight in the Temple of the Goddess |
| **The Hollow King** | None | Endgame raid boss that rewards a second Rebirth Crystal |

### Mobs
- Elemental slimes, spirit foxes, wisp swarms, shadow stalkers, golems of each element

### Pets (given by quests)
- **Spirit Fox** (Wind): speed aura
- **Ember Drake** (Fire): ranged fire breath
- **Tide Turtle** (Water): water breathing and healing
- **Stone Guardian** (Earth): tanky defender
- **Light Sprite** (Light): heals you
- **Storm Cub** (Lightning): shocks enemies
- **Shade Cat** (Dark): night vision and stealth

## Phase 5 - Music, polish and balance
- Original music tracks (day, night, battle, boss, village) and ambient sounds
- Custom spell sounds and casting animations
- Skill balance pass, config file, more quests per element, multiplayer polish
